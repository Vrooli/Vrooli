# Browser rehabilitation progress

This is the bounded resume view, not an execution transcript. Read
[TESTING.md](TESTING.md) and its linked contract before acting. The complete
pre-compaction view is archived and must not be used as resume state.

## Current standing — 2026-09-28 UTC

- Delivery team `browser-automation-studio-delivery` is disabled. No accepted
  candidate or qualification lease exists; the prior representative run ended
  `budget_exhausted/wall_time` and is not acceptance. Do not enable or recreate
  the team.
- The team is now mapped to the canonical Agent Manager enrollment
  `effort:browser-automation-studio-rehabilitation` revision 1. This repairs
  the identity seam without admitting a worker, supervisor, or qualification
  lease; the owner enrollment remains observation-only until the integration
  gates are proven.
- Use the existing Prompt Manager delivery-team and Agent Manager workflow
  owners. Do not add a scheduler, worker-authored controller, Plan Manager plan,
  duplicate ledger, or unrestricted worker campaign control.
- The pinned workflow is worker → independent review → owner qualification.
  Worker limits are 24 tool calls, 16 turns, 900 seconds and 400,000 aggregate
  tokens. Worker/reviewer grants exclude campaign controls, evidence roots,
  lifecycle/restart and qualification effects.
- The active workflow revision now sets both implementation and review
  sandboxes to `networkMode: none`; the prior localhost setting was not safe
  because Workspace Sandbox currently lacks loopback-only enforcement. The
  qualification node retains its explicit owner grants. A direct protected
  canary reached the real bubblewrap path with `allowNetwork:false`; a curl to
  Agent Manager's loopback health port failed with exit 7 and the receipt
  reported `network-deny`. This proves the denied-network backend path, not a
  live BAS worker or Codex hook.
- The active worker contract now continues through the admitted boundary's
  semantic exit gate instead of stopping after an arbitrary twelve-tool-call
  slice. The same hard owner ceilings and duplicate-work guard remain in force;
  a compaction or single repair is still only a checkpoint, not a new epoch.
- The source workflow now lets review use the aggregate budget (no node-local
  turn cap) and no longer carries a stale RF-148 metadata boundary; the owner
  reconciled digest `93e4c14f` while the team remains disabled.
- Owner-validated models are `gpt-6-luna`/medium for delivery and
  `gpt-6-sol`/medium for independent review. The authoritative `/usr/bin/codex`
  catalog and live policy validation confirmed both on 2026-09-28. The generic
  economical Prompt Manager judgment route was refreshed to `gpt-6-luna`/medium
  as well; stale 5.6 selections are retained only as historical aliases.
- Generated-artifact freshness is a shared package/lifecycle obligation:
  `protogen verify`, lifecycle verification and immutable preflight stamps run
  before consumers. Stale generated output fails closed; this is generalized
  beyond Test Genie.
- The repository-wide generated-artifact gate currently passes from its owning
  module: `cd packages/proto && GOTOOLCHAIN=local GOPROXY=off go run -mod=mod
  ./cmd/protogen verify`. This validates the shared source/generated contract,
  not BAS runtime qualification.
- The focused shutdown contract is currently green: api-core forced-close /
  independent-cleanup tests pass, and BAS `services/vision` plus
  `handlers/vision_navigation` suites pass. The managed service is healthy, but
  the current setpoint read reports `candidate_freshness.fresh=false` because
  `playwright-driver/dist/server.js` is stale after the session-teardown edit.
  Do not rebuild until E01's simplification/semantic-exit gate is accepted.
  Runtime restart qualification, owner receipts and the semantic exit gate
  remain open.
- The last fresh managed build was
  `sha256:9125db30fde119a5fe6b169a9ad295873be5e77183e9489b630a6504015029b8`.
  The current setpoint reports `readable=0`, `unavailable=17`, and
  `qualification_bound=false`; current qualification receipts do not exist.
  The managed Codex runner probe succeeds, but it is only a runner-health
  check: the PreToolUse negative canary remains unverified, so unattended
  protected delivery is not admitted. The local policy-runner synthetic canary
  returns the expected deny floor, but does not prove Codex hook dispatch.
- A launch-path audit distinguished direct shell lookup from managed execution:
  the shell's Vrooli attribution shim reaches a user-local 0.141.0 install,
  but Agent Manager's `managedRunnerBinary` deliberately bypasses that shim and
  selects `/usr/bin/codex` or `/bin/codex`; its shim-bypass regression and the
  bounded managed runner probe pass. The resource policy therefore measures the
  same system runner used by managed launches. A real admitted run still has no
  runtime-version receipt because delivery remains disabled; this is an evidence
  gap, not a launch-path blocker. No user configuration or shim was changed.

## Active candidate epoch E01 — navigation observation and managed shutdown

Candidate state: **implementation**

Qualification cycle: **unused**

This single ownership boundary covers status-wait cancellation, authoritative
navigation transitions, managed restart cleanup, driver/browser teardown,
BAS-RF-148, BAS-RF-149, BAS-RF-017, and measured simplification. The worker
cannot choose or close the boundary, edit this file, rebuild/restart managed BAS,
run evidence producers, run qualification, or issue the setpoint.

The last managed build was fresh at
`sha256:9125db30fde119a5fe6b169a9ad295873be5e77183e9489b630a6504015029b8` before the current
UI observer and interrupted-teardown changes; live runtime evidence is stale
until an owner-controlled rebuild.
Existing receipts remain stale or expired; no current qualification receipt is
bound. Do not treat freshness alone as qualification.

## Verified current evidence

- The full UI `record-mode` project passes 643/643, including navigation,
  conversation, sidebar, action-redaction and adjacent recording requirements
  (`J03`, `J04`, `J05`, `J06`, `J13`, `J24`).
- UI TypeScript and scoped ESLint pass. ESLint reports only two existing
  non-null assertion warnings in `actionDisplay.test.ts`.
- API-core server shutdown, BAS navigation handler, vision/redaction, and
  sidecar supervisor suites pass with race detection. Manual supervisor restart
  is channel-fenced and monitor generations are fenced during re-arm.
- Current status transport loss is non-authoritative
  `observation_unavailable`; navigation identity remains stoppable/recoverable.
  Conversation state has a regression proving one assistant message survives
  observation loss and later terminal recovery without duplication.
- Status recovery now owns a separate cancellation controller. A terminal or
  human-handoff WebSocket event cancels its server wait, and starting a
  replacement observation cancels the prior wait; cancellation is silent and
  cannot be misreported as navigation failure. Focused `REQ:BAS-RH-J24`
  coverage is 34/34, including unmount cleanup and late-start fencing.
- A start response that arrives after hook unmount or request cancellation is
  discarded before it can create a status wait or publish a navigation
  identity.
- The generation-fenced navigation and conversation updates have no new hook
  lint findings; sidecar restart admission is shared and race-tested.
- Ordinary and preview-directed orphan-recording cleanup now share one
  keep/protection/order/byte-cap policy owner. On the retained baseline this
  reduced `owner_cleanup.go` from 879 to 871 lines and gocyclo complexity from
  224 to 219; the shared policy regression and API, vision and supervisor race
  suites pass. This is the first measured net reduction in the E01 cleanup
  surface, not whole-BAS acceptance.
- Navigation wire parsing has one dispatcher and shared scalar/enum/field
  readers; action-field complexity is 5 (was 15). Production probes are gone.
- Removed the unreferenced legacy AI-navigation Zod schema family from the
  recording API (169 lines) and unused UI request/response interfaces;
  repository-wide symbol searches found no consumers.
  The live proto-backed service and navigation-domain parser remain the only
  active owners; focused navigation/conversation tests pass 60/60 after the
  removal and UI type-check remains green.
- Inventory including untracked source is 283,112 runtime lines vs 284,443
  baseline (-1,331), but API runtime Go cyclomatic is 16,539 vs 16,405 (+134);
  size alone cannot accept E01.
- Navigation is `567+362+176+13=1,118` lines vs 631 baseline. Its parser,
  event admission and lifecycle are now exclusive owners; parser complexity is
  5 (was 15) and navigation/conversation coverage is 63/63. This cohesion
  rationale is not whole-E01 acceptance; managed proof remains open.
- Interrupted owned-page teardown now snapshots page/video handles before close
  and never closes external-target pages. The new regression passes in
  `manager.test.ts` 75/75; driver type-check, targeted ESLint and diff checks
  pass. Managed restart, recovered-status/privacy cohorts and qualification
  remain unverified.
- The live `tidiness-manager scan browser-automation-studio --type light`
  request timed out at its API boundary (`/api/v1/scan/light`). This leaves the
  scenario-wide tidiness score unverified; the direct ESLint, type-check and
  focused Vitest results above are the applicable bounded evidence for this
  pass. Do not convert the timeout into a clean scan.
- Current source-level shutdown and redaction checks pass. Managed outstanding-
  wait restart, recovered-status privacy, legacy-at-rest/export privacy,
  credential-use preservation, and candidate qualification remain unverified.
- Independent salvage review on 2026-09-28 rechecked the current source: the
  shutdown/observation-loss/raw-action concerns were pre-repair findings and
  are covered by the independent cleanup budget, `observation_unavailable`
  recovery state, and synthetic-secret UI tests. No new defect was accepted;
  managed restart timing, recovered/export privacy, diagnostic-probe ownership,
  and measured whole-surface simplification remain open.
- Agent Manager's shared terminal-accounting retry loop is now repaired before
  unattended BAS delivery: unknown usage remains explicitly incomplete (never
  zero), recent executions retain the late-receipt path, and old terminal
  executions finalize with `accountingFinalizedUnknown` after a one-hour grace
  period when transcripts, receipts, or dispatch bindings are unavailable.
  Focused workflow-runtime, database, and orchestration tests pass; the rebuilt
  service was restarted through lifecycle and workflow-accounting no longer
  appears in startup recovery failures. The active database now has 198
  historical finalized-unknown records and no active BAS delivery run. BAS,
  Swarm Manager, Prompt Manager and Agent Manager declaration plans remain
  valid; the development-toolchain-validator fixture declaration warning is
  repaired and the live sweep is 14/14 reconciled with zero failures. This is
  shared infrastructure evidence, not BAS product qualification.
- Workspace Sandbox initially exposed 33 historical `active` run sandboxes;
  owner recovery safely reclaimed 25 after empty-diff or successful-finalization
  proof. A second owner inspection deleted the six remaining proven-empty rows.
  The BAS worker row was reviewed, its equivalent fix retained in source, and
  its unapproved sandbox rejected. One unrelated failed-finalization heartbeat
  row remains preserved with three files (~12.4 GiB); it is outside this effort.
- Interactive terminal finalization now shares one provenance/lifecycle seam
  for natural completion and operator stop; focused orchestration tests pass.
  This prevents new delete-on-terminal interactive leaks. Recovery now also
  handles omitted historical `autoApply` safely: it inspects the live diff and
  performs a successful no-op finalization only when the diff is empty; rows
  with changes, unavailable diffs, or failed finalization are retained for
  owner review. The one missing-owner row also had an empty diff and was
  deleted via the Workspace Sandbox owner CLI. Focused tests and live recovery
  probes pass.
- Agent Manager was rebuilt/restarted through the managed lifecycle and is
  healthy/readiness-ready at build identity
  `sha256:f6f04be8b6c8a95222d1cd0f2065c60307346bb42ed928f0b6d2ba6b68511487`.
  Owner-level dispatch now requires finite token/charge caps, binds every
  dispatched run identity, and refuses the next admission when canonical
  settlement is missing, unknown, or exhausted. The declared Sol review
  profile was repaired with its required `agent-manager:supervise` ceiling and
  reconciled; the standing owner now has one capped dispatch grant (one run,
  120,000 tokens, 10,000,000 micro-USD, six-hour interval). No child run or
  settlement receipt has been admitted. Prompt Manager now binds the new
  authorization while the supervision team remains disabled; BAS remains
  unqualified.
- Maintained driver session/reset/frame suites pass; historical synthetic probes
  were retired after assertion cross-checking. Shutdown, privacy and qualification
  remain runtime-unverified. Superseded evidence is archived and the live root
  is empty.

## Next bounded actions

1. Continue the genuine parser/lifecycle simplification review. Remove duplicated
  transitions or justify added recovery surface with a comparable metric; the
  new status-wait ownership must be retained only if its cancellation and
  overlap reduction remain covered. Do not count file movement, wrappers, or
  test churn as debt reduction.
2. Preserve focused recovery/admission tests and update this checkpoint only with
   changed, verified, remaining and unverified facts.
3. Before any broad producer run, package loose superseded evidence into one
   dated compressed artifact with a manifest and verify the listing; keep the
   live evidence set under the campaign guard limits.
4. Once the semantic exit gate and measured simplification pass, obtain an
   independent review of the frozen candidate. Only then may the existing owner
   controller issue its one-use worker → Sol review → qualification lease.
5. Do not spend the standing grant while it is authorization-only: its compact
   read has no explicit target and its historical summaries are not current
   GPT-6 admission evidence. Establish a concrete non-BAS target and current
   settlement path first; only then admit one finite probe and verify
   unknown-use refusal. Wake counts, profile turn limits and timeouts are not
   aggregate economic enforcement; unresolved usage keeps admission disabled.
6. Resolve owner-backed review for the one changed no-lifecycle row and the
   failed-finalization heartbeat row; preserve the six proven-empty rows. The
   bounded missing-owner sweep is source-covered and must be verified in the
   next managed build before cleanup is broadened.
7. Refresh only invalidated owner cohorts on the current build, run one exact
   qualification cycle and one setpoint read, then adversarially review the
   result. Do not enable the BAS team before that gate.

## Evidence and history

Campaign guard must remain below its packet/progress/evidence limits. Live
working evidence is currently empty. The superseded cohort is preserved as one
dated compressed artifact with a manifest and verified listing at
`../.vrooli/runtime/rehabilitation-evidence/archive/superseded-working-set-before-e01-refresh-20260928.{tar.gz,manifest.json}`.
Produce a new cohort only after the build is fresh and E01's semantic exit gate
is accepted.

The complete pre-compaction view is retained at
`evidence/rehabilitation/refactor-progress-active-2026-09-28-r4.md.gz` with
manifest `evidence/rehabilitation/refactor-progress-active-2026-09-28-r4.manifest.json`.
Earlier views remain at r3, `refactor-progress-precompact-2026-09-28.md.gz`,
and `refactor-progress-stopped-2026-09-27.md.gz`. Never use an archive as the
resume input or delete a referenced artifact.

This mandate remains active until the operator stops or redirects it.
