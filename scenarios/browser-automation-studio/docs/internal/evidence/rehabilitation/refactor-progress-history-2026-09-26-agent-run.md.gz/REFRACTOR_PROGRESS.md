# Browser rehabilitation progress

This file is the active resume checkpoint, not an execution transcript. Follow
[TESTING.md](TESTING.md). Search only the referenced entries in
[PROBLEMS.md](../PROBLEMS.md). Detailed prior chronology is compressed and is
not routine resume input.

## Epoch summary — current-build profile durability owner — 2026-09-26

Boundary: synthetic alpha/beta profiles must persist their distinct identity
across a managed BAS API/driver restart and leave no active sessions. The
maintained producer passed all five seed checks, both post-restart identity
checks, and cleanup; checkpoint visibility was 101ms. It wrote
`profile-durability-20260926-160100-profile-refresh.json` for the refreshed
managed build.

Focused race checks passed for `handlers/profilevalidation` and
`services/session-profile`. The managed restart completed healthy after a
longer-than-estimated dependency phase; no manual process intervention or
duplicate restart was used. No product source change, assertion weakening,
parallel profile path, or stale receipt reuse was introduced.

Qualification: exact phase `20260926-155314-d7f5a4a2` was run and waited once.
The phase recognized profile durability at L1/Verified, but failed closed on
four unrelated stale owners: passive fidelity, resource budget, motion, and
interactive feedback. The governed findings read was performed once; the
aggregate standing remains L0→L1 and `product_qualified:false`.

Adversarial review found one profile owner, current source/build binding,
durable cleanup, and no profile defect. Counts for this epoch: one managed
restart, zero product rebuilds, one exact evidence phase, one setpoint read.
BAS-FB-036 remains open. Next candidate: refresh the managed passive-fidelity,
crash/reconnect, and browser-semantics owners as the phase-directed foundation
slice; do not treat the four stale findings as product failures. No commits
were made.

## Epoch summary — passive-fidelity owner and receipt selection repair — 2026-09-26

Boundary: current-build passive recording evidence must select the correct
source-bound owner across mixed receipt tags, then prove 10,000 ordered managed
effects, crash/reconnect durability, and browser semantics. The first closure
phase exposed a real validator defect: reverse lexical ordering selected the
older `20260926-fa5d068` semantics receipt over the valid
`20260926-161000-passive` receipt and reported a false source mismatch.

Repair: `latestCrashEvidence` and `latestSemanticsEvidence` now select only
receipts whose contract and required source digests match the current tree.
The focused regression proves a lexically newer stale tag cannot mask valid
current evidence. This removes an evidence-selection failure mode without
adding a second provider path or weakening source binding.

Evidence: targeted passive qualification/provider race tests passed. The
managed owner passed 10,000 effects, unique/increasing journal and applied
sequences, routed temporary storage with zero primary requests; crash/reconnect
passed; all three semantics cases passed. The repaired candidate rebuilt and
restarted healthy on `sha256:b7ec0d7b847dd582cf7c55fdbb4b530451e7d349ede670e4c1858fb5008aff81`.
The exact phase `20260926-160648-01a1219a` recognized passive fidelity at
L1/Verified and failed closed only on six stale owners: evidence completeness,
profile, cancellation, resource, motion, and interactive feedback. The
program setpoint `prog_d77b363c-90b7-49e9-bd0f-cbce903d579a` was read once:
candidate fresh, 0/17 readable, `product_qualified:false`.

Counts: one managed rebuild/restart, two phase attempts (one diagnostic
failure before repair and one closure phase), one governed setpoint read. The
first assembly path typo was corrected without changing evidence. BAS-FB-036
remains open. Next candidate: refresh evidence-completeness for the new build;
do not treat the six stale findings as passive product failures. No commits
were made.

## Epoch summary — current-build evidence completeness owner — 2026-09-26

Boundary: screenshot/outcome write failures, inline telemetry snapshot failure,
missing external video/trace storage, and active-evidence export deletion must
remain explicit, attributable, hashed, and protected. The maintained producer
passed all four named owner tests and wrote a receipt for build
`sha256:b7ec0d7b…`; the execution-writer and retention race cohorts also passed.

The exact phase `20260926-160820-17ca1d77` recognized evidence completeness at
L1/Verified and failed closed on five stale owners: profile, cancellation,
resource, motion, and interactive feedback. The governed setpoint
`prog_8e62dfd3-04c6-4a5a-8f54-7d8ba51b7943` was read once and returned fresh
candidate, 0/17 readable, `product_qualified:false`. No artifact contract or
parallel evidence path changed. Counts: zero restarts, one closure phase, one
setpoint read. BAS-FB-036 remains open. Next candidate: refresh profile and
cancellation together on one managed build.

## Active candidate epoch E04 — profile and cancellation owner refresh

Status: admitted; implementation is unchanged, candidate qualification is false,
and profile durability plus cancellation/recovery are the next current-build
owners. Current managed build: `sha256:b7ec0d7b…`.

### Outcome and boundary

Refresh profile persistence across managed restart and the five-case timeout,
driver-death, accepted-cancellation, API-restart, and retried-start boundary
against one new managed candidate. Preserve uncertain-effect and no-replay
semantics, profile isolation, resource cleanup, source/build binding, and the
existing lifecycle ownership repairs.

### Hypothesis and exit gate

Hypothesis: both owners remain valid but their receipts are bound to the prior
build. One managed restart followed by the maintained profile and cancellation
producers will either establish current evidence or expose a real lifecycle
defect. Close only after both owner receipts pass, focused race checks pass, the
exact phase and one governed setpoint read are recorded, and adversarial review
finds no replay path, leaked session, or duplicate lifecycle owner.

### Next actions

Run profile seed, confirm zero driver sessions, restart once, verify/assemble;
then run the maintained cancellation/recovery producer on the resulting build,
run its focused races, and qualify once at semantic closure. No additional
restart is planned.

## Historical candidate E03 — evidence-completeness owner refresh

Status: admitted; implementation is unchanged, candidate qualification is false,
and evidence completeness is the phase-directed next owner. Current managed
build: `sha256:b7ec0d7b…`.

### Outcome and boundary

Refresh the four artifact-integrity owner cases for the current build:
screenshot/outcome write failures, inline telemetry attribution when snapshot
storage fails, missing external video/trace acknowledgment, and deletion
protection during export. Preserve explicit failure state, hashes, ownership,
and retention semantics; do not add a parallel evidence registry or shortcut
the provider validator.

### Hypothesis and exit gate

Hypothesis: the evidence-completeness implementation is valid but its retained
receipt is bound to the prior build. The maintained producer and race cohorts
will either establish current evidence or expose a concrete artifact contract
defect. Close only after all four named owners pass, source/build/artifact
binding is current, focused races pass, the exact phase and one governed
setpoint read are recorded, and adversarial review finds no deletion bypass or
unattributed artifact.

### Next actions

Run `api/cmd/evidence-completeness-cohort/qualification.mjs` against the healthy
managed build, run its documented focused race cohorts, inspect the receipt,
then qualify once at semantic closure. No restart is planned unless source
changes invalidate the live build.

## Historical candidate E02 — passive-fidelity owner refresh

Status: implementation repair in progress; sensor readiness is mixed, and
candidate qualification is false. The program setpoint read
`prog_cb5c7ff6-cc3c-4b2c-a15f-009c0589bc9b` returned a fresh candidate but 0/17
readable rows. Its explicit next move is the managed passive-fidelity,
crash/reconnect, and browser-semantics owner batch.

### Outcome and boundary

Refresh the passive recording boundary so 10,000 ordered managed browser
effects, recording-service process death/reconnect, and the three selected
browser-semantics journeys are independently observed, source-bound, and
assembled for the current managed build. Preserve the existing profile,
cancellation, evidence, and recording contracts; do not add another journal,
reconnect path, receipt shortcut, or assertion weakening.

### Hypothesis and exit gate

Hypothesis: passive-fidelity implementation is present but its retained owner
receipts are stale after the current build refresh. Running all three documented
owners and assembling once will either establish current evidence or expose a
real recording defect. The slice closes only when all three owners pass,
assembly binds one live build and current source/contract digests, focused
recording tests pass, the exact evidence phase and required setpoint read are
recorded once, and adversarial review finds no duplicate ownership or replay
ambiguity.

### Measured defect and repair

The first current-build phase selected the older `20260926-fa5d068` semantics
receipt because reverse lexical ordering ranked that tag above
`20260926-161000-passive`; it then reported a source-digest mismatch despite a
passing current receipt. `latestCrashEvidence` and `latestSemanticsEvidence`
now select receipts whose contract and required source digests match the live
tree, with a regression covering a lexically newer stale tag. Focused race
tests pass. This repair intentionally rejects all stale candidates when no
current source-bound receipt exists.

### Next actions

After the managed rebuild/restart, run the managed 10,000-action owner, the recording process-death/reconnect
owner, and the three browser-semantics cases with a fresh tag; assemble their
receipts; run the documented focused race/tests; then qualify once at semantic
closure. If a producer fails, repair only the named W3 owner and remeasure it.
No managed restart is planned unless a producer requires it or source changes
invalidate the live build.

## Historical stopped candidate E01 — current-build foundation owner refresh

Status: implementation is unchanged; this bounded evidence slice is admitted
for profile durability, with resource-budget and passive-fidelity owners next
only after their required preconditions are confirmed. Sensor readiness is
mixed and candidate qualification remains unknown. Preserve the dirty worktree
and do not commit.

### Outcome and boundary

Refresh one independently shippable current-build foundation boundary: a
profile seeded before a managed BAS restart must be recoverable afterward with
the same durable data, no leaked sessions, and an owner receipt bound to the
current source and build. This continues the accumulated rehabilitation work;
it does not authorize unrelated product changes or piecemeal score refreshes.

Affected journey: profile persistence across managed restart and subsequent
session cleanup. The directly related follow-up owners are resource budget and
passive fidelity; they remain outside this slice until their own producer
preconditions are satisfied. Shared invalidation roots are API/driver/UI source
identity, `.vrooli/service.json`, lifecycle freshness, managed browser state and
the current owner receipts.

Hypothesis: the profile owner is already implemented, but its current-build
sensor is stale. A fresh seed/restart/verify/assemble cycle will either prove
durability and cleanup without a product change or expose a concrete
source-bound defect; stale aggregate findings alone will not be treated as a
product failure.

### Semantic exit gate

Keep this slice open until all of the following are true:

- the profile producer passes seed, managed restart, verify and assembly with
  current source/build identities;
- focused profile, source-binding and race checks pass without changed product
  assertions or timeout weakening;
- the receipt is retained in the bounded working set and the exact evidence
  phase plus governed setpoint are each run once at closure;
- adversarial review finds one lifecycle owner, no stale receipt reuse, no
  parallel profile path, and no unresolved profile defect.

Permitted split conditions are only those in TESTING.md. Context compaction,
elapsed time, one green package or an isolated L1 standing does not close the
slice.

### Current truth

- **Implementation:** profile durability has an owner producer and focused
  validator; no product source change is planned unless the fresh cohort
  falsifies the contract.
- **Sensor readiness:** evidence-completeness and cancellation/recovery are
  current-build L1 individually; profile, passive, resource, motion and
  interactive aggregate rows still have stale or missing current receipts.
- **Candidate qualification:** current managed build is
  `sha256:2707a7388aa1e4b42f602654f6066a6708d5ab5d7031bffce2d313ae56f8a4b4`.
  The last governed setpoint was 0/17 readable with
  `product_qualified:false`; it is not refreshed until this owner closes.

No new lifecycle restart, evidence phase or setpoint has been run for this
admitted profile slice yet.

### Resume exactly here

1. Create one new ignored profile evidence directory and run seed.
2. Confirm the managed service is idle, restart once through `make`, then run
   verify and assemble; do not hand-compose receipt JSON.
3. Run focused profile/source-binding/race checks and inspect the receipt for
   current build identity, durable data, cleanup and no replay ambiguity.
4. Run the exact evidence phase once and the governed setpoint once only if the
   profile semantic exit gate is satisfied; then replace this checkpoint with a
   compact epoch summary and select the next stale owner.

### E01 source reconciliation — historical snapshot

The prior E01 boundary map and diagnostic setpoint are historical. Capture,
session, viewer, manifest, and evidence owners passed their focused checks; the
semantic exit gate remained open for current-build receipts and adversarial
review. This section is historical; resume from the newest active checkpoint
or epoch summary at the top of this file.

## Evidence and documentation maintenance — 2026-09-26

The runtime evidence root measured 610 files, about 38 MiB and 977,008 text
lines before cleanup. Superseded top-level attempts and the 304-file raw capture
cohort were moved to two recoverable archives. Archive listing and SHA-256 were
verified before originals were removed. The directly readable working set is
now 31 files, 5,608,203 bytes and 134,066 text lines, within TESTING.md's
128-file/16-MiB/250,000-line budget.

Manifest:
`.vrooli/runtime/rehabilitation-evidence/archive/epoch-protocol-cleanup-2026-09-26.manifest.json`.
The archive SHA-256 values are `ec093bd91efb78df90ed9c23260d060d8277b79bcbd5a9eb0bbd80b7d063996f`
and `979ea0d6dac51e85b9f24af3e07fbc0d6d770e8741530449de0964d58ff693bb`.
This cleanup changes evidence storage only; it does not promote or invalidate a
product result.

The complete pre-compaction feedback ledger is preserved as
[`operator-feedback-history-2026-09-26.md.gz`](evidence/rehabilitation/operator-feedback-history-2026-09-26.md.gz)
(SHA-256 `ae92b5350d625ee6ae3a0b576ad3354a7bfa1e87ec9b3435ea5298d3ea97e0db`).
The previous active progress is preserved as
[`refactor-progress-snapshot-2026-09-26.md.gz`](evidence/rehabilitation/refactor-progress-snapshot-2026-09-26.md.gz)
(SHA-256 `c70ec68f474376aa4ab60b1ea641e2ae084ced9191a3d55df136406ea5c1358c`).
Earlier W228–W266 history is preserved as
[`refactor-progress-history-2026-09-25.md.gz`](evidence/rehabilitation/refactor-progress-history-2026-09-25.md.gz)
(SHA-256 `35f2231f66373a3881b2a22096924f5258e5b26a04fb86d5f43a5fd1662b51b6`).
Retrieve any of these with `gzip -cd <path>` only when a current decision needs
the historical detail.

## Recent epoch summary

Before the protocol change, W267–W277 repeatedly refreshed build-bound evidence
around focused repairs. The useful durable results were: lifecycle freshness is
now read by the setpoint; duplicate closure-cache work and the root API response
deadline were repaired; capture construction was decomposed; the viewer's
delayed-paint frame loss gained a deterministic regression and bounded queue;
owner cohorts reached clean observations on prior candidates; and shared browser
sessions were not closed to force qualification. The repeated candidate resets,
score reads and receipt refreshes are historical evidence of the inefficient
cadence that E01 must not repeat.

## Next adversarial epoch admission — 2026-09-26

The clean rehabilitation phase triggered the required fresh adversarial review.
The next boundary is the retained isolated-regression harness and its driver
recording ownership, not another broad qualification refresh. The focused
`refactor_regressions.py --case recording-driver` gate currently exits 2:
`refactor_probes.cjs` loads the retired
`playwright-driver/src/frame-streaming/websocket/server.ts` path, and its
recorder fixture never sends the required recording-start control message, so
the clear-field probe observes no events. Search recall found related prior
work BAS-WORK-167/168/169, indicating likely harness drift/recurrence rather
than a new product claim; the current probe must still be proven against the
actual modules.

Falsifiable hypotheses:

1. The empty-field observation is a stale fixture setup: adding the documented
   start control to the synthetic recorder should produce `a`, `ab`, and
   `''` without product changes. If it remains empty, the recorder path is
   broken.
2. The direct frame probe is a retired ownership path: the driver no longer
   owns `DirectFrameServer`, so removing that probe from the driver pack and
   relying on the API frame-hub owner should make the driver producer usable.
   If no current owner covers the behavior, add/repair the owner at its actual
   API boundary rather than preserving a dead import.
3. The failure is an actual recorder regression despite prior fixes: the
   maintained recording-injection/timeline owners will fail or disagree after
   the fixture is corrected. Those tests are the discriminating product check.

The recording-driver hypothesis was confirmed: after adding the required start
control, browser globals, response acknowledgement, and collision-aware fixture
behavior, the probe exits 0 and observes `a`, `ab`, and the final empty value;
maintained record-input, recording-injection, and timeline tests pass 63/63.
Removing the retired direct-frame driver probe was also correct because frame
ownership now lives at the API boundary. The producer now reports the actual
source SHA instead of masking producer stderr as a JSON parse error.

The broader pack currently reports 7 passed, 1 failed, and 2 unavailable. The
passing owners include recording driver/API, profile, input, retention,
execution API, and execution driver. The remaining reuse failure is a real
current-owner mismatch in the synthetic evidence handoff (accepted reuse keeps
the prior execution's trace/HAR/video destinations and does not enable newly
requested capture); the session-frame and stream packets still have stale
fixtures for the current page-stack/store and frame-resize/CDP APIs. These are
the next bounded adversarial debt items; they are not being relabeled as
product failures without a maintained-owner contradiction.

Independent gates remain green: the 16 internal Python tests pass, the BAS
contract preparation check has no errors, driver TypeScript passes, and the
input-feedback ESLint run is warning/error free. No managed rebuild or
rehabilitation refresh is needed for these probe-only changes.

## Ownership-boundary repair — semantic exit pending — 2026-09-26

The adversarial pack exposed three actual ownership defects beneath the stale
fixtures. Session reuse now treats video, HAR, tracing, performance-trace and
accessibility capture as execution-owned state; any retained or requested
capture forces a fresh context so artifact paths and required capabilities are
resolved for the new execution before readiness. Session reset now rejects
externally controlled targets and retains `session.page` as the active tab
instead of always keeping `pages[0]`. The UI frame decoder now closes an
in-flight bitmap when a newer frame has already been admitted, preventing
stale pixels from entering the paint queue.

Affected owners and defects: BAS-RF-043, BAS-RF-044, BAS-RF-046, and the
related stream observability boundary BAS-RF-047. The retained reuse,
session-frame, and stream probes now pass; the full isolated pack is 10/10.
Maintained focused suites pass 80/80, internal Python checks pass 16/16, the
contract check is error-free, driver TypeScript passes, and the input-feedback
ESLint run is warning/error free. This is a measured behavior improvement, not
helper movement: capture ownership is explicit, active-tab reset is preserved,
and stale frame work is closed at the decoder boundary.

## Semantic gate result — 2026-09-26

Managed build `sha256:261166e95fd…` passed evidence, resource, profile,
cancellation, passive, and motion owners; local interactive passed, while
emulated-remote interactive remained unqualified. Exact phase
`20260926-090744-86e7a1bf` failed only interactive feedback; setpoint
`prog_78b50cac-05f1-42b0-b65f-efc763f556ca` was fresh but 0/17 readable and
correctly false because receipts/capture were stale. Probes 10/10, focused
suites 80/80, frame-stream 34/34, Python 16/16, and adversarial review passed.
BAS-FB-036 remained open for volume reduction.

## Epoch summary — interactive transport continuity — 2026-09-26

The shared WebSocket provider now reports whether a send was actually admitted;
input forwarding immediately uses its existing HTTP path when the socket closes
between React connection state and the send call, preventing pending input from
waiting for reconnect. The interactive owner now observes both WebSocket and
HTTP-fallback receipts, preserving the same 1,000-input correlation and latency
assertions. This was a product reliability repair plus an owner-observability
correction, not an assertion relaxation.

Managed build: `sha256:f993bf284b9baf16be65cfaeec6607843821e07e815395c227d82404b04780a7`.
Local and emulated-remote interactive cohorts passed 1,000/1,000. Current
motion, capture, evidence, profile, cancellation, passive, resource and
interactive owners all passed; exact phase `20260926-093404-9c679f08` passed
at L1 maximum maturity. Exact setpoint
`prog_2c949f5a-5a5c-4f0d-a337-a8d6de53828e` is fresh with 7/17 readable,
all seven owner-backed rows in band, and 10/17 pending telemetry;
`product_qualified:false` remains correct.

Epoch counts: 1 managed rebuild, 2 managed lifecycle restarts, 1 exact
rehabilitation phase, and 1 exact setpoint read. Adversarial review passed
retained probes 10/10, maintained focused suites 80/80, UI input/frame owners
47/47, internal Python checks 16/16, contract preparation with no errors,
driver TypeScript and ESLint. No commits were made. BAS-FB-036 remains open:
this epoch did not demonstrate a net test-code volume reduction. Next epoch:
archive superseded runtime evidence to restore the working-set budget, then
measure and simplify duplicated BAS owner-test infrastructure without moving
code for score only.

## Evidence retention and setpoint binding — 2026-09-26

The superseded runtime evidence was moved into the recoverable archive
`archive/superseded-runtime-evidence-2026-09-26T09-38-19Z.tar.gz` after its
top-level listing was verified. The archive contains 198 top-level entries,
824 files, and 49,203,538 uncompressed bytes; its SHA-256 and retrieval command
are recorded in the adjacent manifest. The active evidence working set is now
6,841,478 bytes and 148,501 text lines across 24 top-level entries, below the
documented retention limits.

The exact setpoint reader had a real contract-integration omission: the
17-row rehabilitation contract declared `interactive-feedback`, but the
owner-backed capability binding enumerated only six other capabilities. The
reader now consumes the interactive standing from the same exact phase
findings, and the program-runtime regression fixture requires a clean L1
interactive standing. The supported workflow test suite passes 51/51.

The exact setpoint command was rerun as
`prog_44097eac-4943-4e59-b704-3b273f7b31ed`; candidate freshness remains true
for build `sha256:f993bf284b9baf16be65cfaeec6607843821e07e815395c227d82404b04780a7`,
and the board now reads 8/17 rows with 9/17 pending telemetry. The product is
still honestly `product_qualified:false`; the remaining rows are not being
manufactured from unrelated observations. BAS-FB-036 remains open: this epoch
reduced evidence duplication and repaired the setpoint binding, but did not
yet demonstrate a net BAS owner-test code-volume reduction. Next epoch:
inventory the duplicated owner-test infrastructure and identify one
behavior-preserving extraction candidate with a maintained regression.

## Epoch summary — owner receipt identity utilities — 2026-09-26

The four owner producers now share one tested identity/hash utility for health
normalization and SHA-256 file hashing. Each producer still supplies its own
source list and managed-build identity, and the Go validators now include the
shared helper in their fail-closed source provenance. Receipt schemas,
qualification bands, and product behavior are unchanged. The profile producer
was intentionally left as a comparison case because its hashing is coupled to
staged harness provenance.

The selected producer set fell from 1,230 lines to 1,184; the 21-line helper
leaves a 25-line net reduction, and five duplicate identity/hash definitions
became one shared implementation. Focused helper tests pass 2/2; the five Go
receipt-validator packages pass; program-runtime tests pass 51/51; contract
tests pass 15/15; refactor probes pass 10/10; motion driver tests pass 29/29;
driver typecheck passes. The first motion refresh had a transient 8,506-frame
miss, an isolated rerun had 8,994, and the focused rerun passed at 9,000/9,000
with the slow-reader assertions intact. The adversarial source review found
and fixed two motion-owner lint defects before the final refresh.

Current managed build is
`sha256:fa5d06805490638d41adb9e6a6749a339f6bd10a4420b5c6c93d4f990b751905`.
Current owner evidence passes evidence completeness 4/4, resource budget,
cancellation/recovery 5/5, passive fidelity (10,000 actions plus crash/
reconnect and 3 semantics cases), profile durability, motion 9,000/9,000 plus
slow-reader checks, and local/remote interactive feedback 1,000/1,000 each.
Capture health is within budget at p95 418 ms across 100 samples.

The final exact rehabilitation phase passed as
`20260926-102817-83bcd7dd`, with all seven available capabilities clean at L1.
The final exact setpoint read is
`prog_0e46b512-5645-4523-a5c5-b6695e92e80b`; it is fresh for the current build,
reads 8/17 rows, and correctly leaves 9/17 rows pending telemetry with
`product_qualified:false`. Epoch counts were two managed lifecycle refreshes,
two exact phase attempts (the first preceded the final motion-owner lint fix),
and two exact setpoint reads (the first likewise preceded that invalidation).

Superseded evidence is recoverable in the dated archives
`archive/superseded-owner-refresh-2026-09-26T10-09-51Z.tar.gz`,
`archive/superseded-stale-f993-receipts-2026-09-26T10-19-44Z.tar.gz`, and
`archive/superseded-motion-before-owner-lint-2026-09-26T10-27-56Z.tar.gz`;
each has an adjacent manifest with its SHA, contents, and retrieval command.
The active working set is 329 files, 6,838,631 bytes, and 148,278 text lines;
the high file count is from retained current capture/profile cohorts, while
bytes and text lines remain below the documented limits.

Repository-wide lint remains a known limitation: it reports 157 errors and
560 warnings across pre-existing/unrelated areas. The changed input owner is
clean, and the changed motion owner has zero errors and eight existing warning
classes. This keeps BAS-FB-036 open: this epoch demonstrated a measured
reduction in selected qualification infrastructure, but not a repository-wide
test-infrastructure cleanup. No commits were made.

## Epoch summary — owner-test CDP/session fixture hygiene — 2026-09-26

The CDP frame-streaming owner tests now use one typed synthetic page/CDP
fixture builder. Four unnecessary session-spec assertions were removed,
non-awaiting async factories became explicit promises, and unsafe fixture
non-null access became explicit guards. No product source, owner receipt,
source list, managed build, qualification evidence, or behavioral assertion
was changed.

Selected test infrastructure fell from 1,219 to 1,190 lines, and repeated page
setup was consolidated. Targeted lint fell from 28 CDP errors plus 4 session
errors to 0 errors / 18 warnings; no lint rule or assertion was suppressed.
The focused CDP/session suites pass 41/41, driver typecheck passes, all 10
retained regression probes pass, targeted diff hygiene passes, and contract
preparation passes 15/15 after superseded E01 narrative was compacted.

This was a test-infrastructure improvement attached to the frame-streaming
ownership boundary. Product source and owner bindings were unchanged, so no
managed rebuild/restart, owner refresh, exact phase, or setpoint read was
warranted. The remaining 18 warnings are honest successor debt. BAS-FB-036
remains open. Adversarial review found no assertion weakening, ownership drift,
dead-path retention, or product regression; no commits were made.

## Epoch summary — remaining owner-test static hygiene — 2026-09-26

The motion and CDP qualification owners now have explicit callback, fixture,
promise, packet, and observation types. Motion fell from 8 warnings to 0 and
CDP from 18 to 0; no lint rule, assertion, or requirement was weakened. The
CDP page fixture is shared across 16 cases, with two specialized page literals
remaining for distinct browser-context behavior.

The selected files are 1,767 lines versus the 1,761-line pre-epoch baseline:
six lines were added for explicit type contracts while 26 diagnostics and most
repeated page setup were removed. This is accepted as a measured maintainability
reduction because the warning debt reached zero and the shared fixture replaced
repeated unsafe setup; it is not claimed as a code-volume reduction. Focused
CDP/session tests pass 41/41, motion/CDP/session targeted ESLint is clean,
driver typecheck passes, all 10 retained regression probes pass, contract
preparation passes 15/15, and scoped diff hygiene passes.

No product source, owner receipt, source list, managed build, qualification
phase, or setpoint was invalidated. The current setpoint remains fresh at 8/17
readable for `sha256:fa5d068…`, with 9 telemetry rows pending and
`product_qualified:false`. BAS-FB-036 remains open because selected code volume
did not fall. No commits were made; adversarial review found no assertion
weakening, ownership drift, dead-path retention, or product regression.

## Epoch summary — profile durability and video teardown — 2026-09-26

The profile-storage owner fell from 341 lines with 10 errors/21 warnings to
zero targeted diagnostics. Typed storage/response seams and lifecycle guards
preserve the seven authentication, reset, isolation, capture, and file-origin
tests. A teardown defect was fixed: video handles remain live through context
flush before completed videos move; integration and unit regressions cover it.
Focused tests pass 7/7; manager flush, typecheck, lint, contract, and probes
pass.

Qualification used managed build `sha256:f077e12e…`; exact phase
`20260926-111122-a1726dbb` passed clean L1. Setpoint
`prog_6dfe8ccb-a996-45b0-9cf6-90f7bcd3f2ee` remained false because telemetry
referenced the prior build; capture was refreshed afterward (p95 447ms, 100
samples), without rereading. Counts: one rebuild/restart, one profile restart,
three phase attempts, one setpoint read. BAS-FB-036 remains open

## Epoch summary — record-mode owner typing — 2026-09-26

`record-mode.test.ts` has explicit navigation, page, session, request, response,
and callback contracts. Its 112/112 tests pass; ESLint fell 15/13→0/0, with
typecheck, driver probes, diff hygiene, and contract 15/15 passing. It is 413
lines versus 407, so no volume reduction is claimed; no product or receipt
changed.

## Epoch summary — record-mode lifecycle owners — 2026-09-26

The adjacent page-events and recording-lifecycle owners use typed event bodies,
fixture seams, promise mocks, and guarded timeline entries. Their 52/52 tests
pass; diagnostics fell 15/37→0/2, with typecheck, driver, contract, and diff
hygiene passing. The pair is 853 lines versus 841, so no volume reduction is
claimed.

## Epoch summary — shared deferred fixtures — 2026-09-26

Added `createDeferred<T>` to the existing test-helper barrel and replaced the
duplicated deferred-promise fixtures in the page-events and recording-lifecycle
owners. This is a net six-line reduction across the helper plus both owners;
the route-specific page/session fixtures remain local. Record-mode, page-events,
and lifecycle tests pass 164/164; typecheck, contract (15/15), recording-driver
probe, targeted ESLint (0 errors, 2 existing warnings), and diff hygiene pass.
Prettier check still reports pre-existing style drift in the three touched files;
no formatting rewrite was applied. Test-only change: no receipt or qualification
refresh is required.

## Epoch summary — SessionManager owner cleanup — 2026-09-26

The SessionManager test owner now uses one typed `createSessionSpec` factory for
the repeated default setup, with explicit lifecycle return contracts and guards
for optional pipeline, trace, and video state. The owner fell from 1,059 to 980
lines (79 fewer), ESLint from 13 errors/9 warnings to 0/0, and assertions were
balanced in adversarial diff review. Session tests pass 184/185 (one existing
skip); manager tests pass 68/68; typecheck, contract 15/15, recording-driver
probe, and diff hygiene pass. Jest's handle detector exits cleanly without a
reported handle. Test-only change: zero rebuilds/restarts, exact evidence phases,
or setpoint reads; qualification and receipts remain valid and unchanged.

## Epoch summary — polling/frame-streaming owner — 2026-09-26

Promoted one typed polling fixture across both polling test groups, reusing the
existing Playwright mock and deferred helper; removed the duplicate local page,
socket, protocol, stats, and deferred setup. Polling fell from 344 to 340 lines
and diagnostics from 6 errors/10 warnings to 0/0. The polling owner passes 15/15
and the full frame-streaming unit owner passes 67/67; typecheck, contract 15/15,
recording-driver probe, adversarial assertion review, and diff hygiene pass.
The four removed versus five added assertion-line count reflects one metadata
assertion split into a shape check plus timestamp check; no behavior assertion
was weakened or removed. Test-only change: zero rebuilds/restarts, evidence
phases, or setpoint reads; qualification and receipts remain unchanged.

## Epoch summary — complete pipeline-validation owner — 2026-09-26

Shared capture/deferred seams reduced this owner 781→771 lines and diagnostics
1/25→0/18; full owner 37/37, typecheck, driver, contract 15/15, and diff checks
pass. Remaining warnings are the untyped `ws` surface; test-only.

## Epoch summary — native capture/transport owner — 2026-09-26

Shared JPEG decoding reduced the capture/transport slice 228→210 lines and
diagnostics 1/31→0/23; focused tests 6/6, typecheck, driver, contract 15/15,
and diff checks pass. DPR-height flake isolated; reruns passed. Test-only.

## Epoch summary — native stream-controls owner — 2026-09-26

Typed decoder/ws seams reduced the owner 149→141 lines and 3/38→0/38
diagnostics; focused 10/10 and full 37/37 pass, as do typecheck, driver,
contract 15/15, and diff hygiene. Test-only.

## Epoch summary — typed-action owner family — 2026-09-26

Typed the main, native-frame, SDK acknowledgement, and viewport owners; shared
fixtures, removed dynamic evaluation, and added guards. Main 1,232→1,181 lines;
full file 29/29; typecheck, driver, contract 15/15, and diff checks pass.

## Epoch summary — pipeline WebSocket fixture owner — 2026-09-26

Added typed server/socket wrappers and local wait seams for the `ws` fixture;
the pipeline owner is now 0/0 diagnostics from 0/79, with no assertion changes.
Full pipeline tests pass 37/37; typecheck, driver, contract 15/15, and diff
checks pass. Test-only.

## Epoch summary — recording context-initializer fixture owner — 2026-09-26

Consolidated repeated route-handler lookups and page-context mocks, and completed
the shared request mock with the `frame()` seam required by the event route.
The owner fell 989→936 lines and remained 0/0 diagnostics; focused tests pass
30/30 and typecheck passes. Test-only; evidence and qualification unchanged.

## Epoch summary — CDP screencast viewport fixture owner — 2026-09-26

Introduced one typed viewport fixture seam shared by reconnect and resize-control
tests, preserving CDP acquisition, closed-page, viewport, and teardown behavior.
The owner fell 1,056→1,054 lines with diagnostics remaining 0/0; the full owner
passes 29/29, typecheck and diff hygiene pass. Test-only; qualification unchanged.


## Epoch summary — frame-streaming manager fixture contract — 2026-09-26

Typed strategy, handle, WebSocket, configuration, and session-provider seams;
replaced unsafe mock-result access and a non-null assertion. Diagnostics fell
1/40→0/0; focused tests 19/19. Types added 34 lines
(379→413), traded for eliminating 40 unsafe diagnostics.
Test-only; no rebuild/restart/phase; qualification unchanged. Setpoint read
`prog_c86801b8-4b30-4a18-83e2-d0ef685cf2e2` returned 1/17 readable, 16/17
unavailable; `product_qualified=false`.

## Epoch summary — instruction-executor registry fixture owner — 2026-09-26

Consolidated repeated handler-registry doubles and typed the failure/telemetry
promise seams. The owner fell 255→251 lines and diagnostics 2/4→0/0; focused
tests pass 12/12 and typecheck passes. Test-only; qualification unchanged.

## Epoch summary — conditional expression fixture owner — 2026-09-26

Typed the page-evaluate seam and expression/presence matrices; diagnostics
4/3→0/0, tests 24/24, and typecheck pass. Test-only; qualification unchanged.

## Epoch summary — AI action-executor compatibility surface

Removed unused `typeDelay` config and legacy paths; no callers remain. Source
fell 598→543 lines. Action/vision tests 67/67; typecheck/lint/diff pass. One
restart; phase `20260926-130853-a7a423a7` failed closed on seven stale receipts
for `sha256:22d6d3f…`; setpoint `prog_f586ee37-a040-4a15-aee0-33e75960856f`
read 0/17, `product_qualified=false`.

## Epoch summary — SessionManager registration convergence

Converged duplicate registration into shared diagnostics,
pipeline readiness, instrumentation, and metrics. Manager 1,268→1,251 lines;
tests 68/68, handle/typecheck/diff pass; lint 0 errors/6 warnings. Restart 1;
phase `20260926-131838-2783bf53` failed
closed on seven stale receipts for `sha256:fc39d7c…`; setpoint
`prog_349c3d75-3c4e-48bd-8334-69c69f218a11` 0/17, `product_qualified=false`.

## Epoch summary — network route registration — 2026-09-26

Consolidated URL compilation and idempotency preparation for mock, block,
modify-request, and modify-response routes into one owner. Operation-specific
callbacks and registration metadata remain unchanged; source 671→667 lines.
Network/idempotency tests pass 10/10, typecheck passes, changed-owner ESLint is
0 errors/0 warnings, and diff hygiene passes. Managed restart was healthy.
Phase `20260926-132919-0ceabafd` failed closed on seven stale/missing receipts
for live build `sha256:6c96a15e…`; no product assertion failed. Setpoint
`prog_efe77a1e-912b-4704-b32b-8ff59ea68d7f` completed with 0/17 readable and
`product_qualified=false` because retained workload and owner receipts were for
older builds. The next boundary is selected after this fresh-build gate.

## Epoch summary — tab handler result policy — 2026-09-26

Centralized repeated user-error construction across open, switch, close, and
list paths; exact messages/codes remain unchanged. Source 549→441 lines;
tab-idempotency tests 8/8, typecheck, changed-owner ESLint 0/0, and diff check
pass. Restart was healthy. Phase `20260926-133401-33b84c80` failed closed on
seven stale/missing receipts for `sha256:842a9c94…`; setpoint
`prog_73d145de-b044-4f07-9885-30831581ed4a` read 0/17,
`product_qualified=false`. Qualification remains unavailable, not a product
failure.

## Epoch summary — recording verification gate — 2026-09-26

The reducer now requires `eventRouteActive` before entering `ready`, matching
its diagnostic/error contract; inactive routes produce recoverable
`EVENT_ROUTE_FAILED` instead of admitting recording. State-machine tests pass
35/35 (including the new regression), typecheck/lint/diff checks pass, and the
contract check passes 15/15. Restart was healthy. Phase
`20260926-133832-23725fa1` failed closed on seven stale/missing receipts for
`sha256:eb84e523…`; setpoint `prog_093f41c5-ea17-4f51-887d-6207b8c2033b`
read 0/17 with `product_qualified=false`. This is unverified qualification,
not a product assertion failure.

## Epoch summary — event-route concurrency — 2026-09-26

Forced route re-registration now honors the existing per-page setup lock;
concurrent navigation/activation cannot install duplicate event handlers while
sequential `force=true` re-registration remains supported. Context-initializer
owner tests pass 31/31, typecheck/lint/diff checks pass, and the contract check
passes 15/15. Restart was healthy. Phase `20260926-134128-2f876543` failed
closed on seven stale/missing receipts for `sha256:7dd2af06…`; setpoint
`prog_71134128-f79c-4f54-87b1-7403ab7a07b8` read 0/17 with
`product_qualified=false`. Qualification remains unverified, not a product
assertion failure.

## Epoch summary — injection strategy auto-selection — 2026-09-26

Automatic detection now tries only `init-script` and `cdp-injection`; the
deprecated `route-injection` implementation remains available when explicitly
named, preserving the compatibility boundary. Factory/auto-detector tests pass
38/38, typecheck and changed-owner lint pass (only two pre-existing test-mock
warnings), and diff hygiene passes. Restart was healthy. Phase
`20260926-134642-750a1da5` failed closed on seven stale/missing receipts for
live build `sha256:5c414eaf…`; setpoint
`prog_eed5b1ee-ba99-4004-b681-00e4c50f6bfc` read 0/17 with
`product_qualified=false`. Qualification remains unverified, not a product
assertion failure.

## Epoch summary — recording context initializer ownership — 2026-09-26

Boundary: `recording/io/context-initializer.ts` and its maintained owner tests;
preserve page setup ordering, route registration, context reuse, and teardown
behavior. Hypothesis: completion-only idempotency permits overlapping callers to
construct duplicate injection setup and event-route registration. Baseline:
`initialize()` guarded only `initialized`, with no in-flight ownership; the
initializer owner is 589 production lines and its maintained test owner is 953
lines before this epoch's already-batched fixture cleanup. Expected improvement:
one shared in-flight setup per initializer, retryable after failure, without
changing the explicit injection strategy or page routing contract. Added the
initialization promise boundary and concurrent-caller/retry regressions; the
full owner passes 33/33. Production source is 589→614 lines because the
explicit lock/retry ownership replaces unbounded duplicate setup; the test
owner is 953→985 lines including maintained fixture cleanup and two
discriminating regressions. Typecheck, changed-owner lint, diff hygiene, and
contract preparation pass. Two managed restarts were healthy; the second was
required after the adversarial retry regression changed the candidate tree.
Phase runs `20260926-135256-c8a2c9e0` and `20260926-135529-cdea58e8` each failed
closed on seven stale/missing receipts for live builds
`sha256:c867d17e…` and `sha256:3a1806f7…`; setpoint reads
`prog_6207b849-d53f-49f7-8159-b189fadac404` and
`prog_55bead61-c1e8-4bd4-b587-b4edfd4576ba` both read 0/17 with
`product_qualified=false`. Qualification remains unverified, not a product
assertion failure. Adversarial review found the next actionable defect:
`pipeline-manager.ts` currently sets `eventRouteActive` with `|| true`, making
the readiness check non-discriminating.

## Epoch summary — pipeline verification route truthfulness — 2026-09-26

Boundary: `recording/orchestration/pipeline-manager.ts` verification and its
maintained readiness/state-machine owners. Preserve recording start, retry,
route setup, event delivery, and the existing recoverable error contract while
making route readiness reflect an actual owner signal. Hypothesis: the
unconditional `|| true` admits `ready` without proving the event route is
active, allowing recording to start with lost events. Baseline: prior state
machine repair requires `eventRouteActive`, but pipeline verification always
reports it true. Expected improvement: eliminate the false-positive readiness
path and add discriminating no-route, active-route, and recovery verification.
Exposed the event-route registration predicate, removed the unconditional
fallback, made route recovery re-verify rather than reuse stale failed
verification, and allowed fresh verification from recoverable errors. Focused
owners pass 72/72; typecheck and diff hygiene pass; changed-owner lint has 0
errors and 3 pre-existing explicit-return-type warnings in
`pipeline-manager.ts`. Contract preparation passes. One managed restart was
healthy. Phase `20260926-140515-775edae6` failed closed on seven stale/missing
receipts for live build `sha256:235e8566…`; setpoint
`prog_be71f780-4e38-4e43-bc63-7a8f4a828243` read 0/17 with
`product_qualified=false`. Adversarial review found no additional defect in
this route-verification boundary; qualification remains unverified, not a
product assertion failure.

## Epoch summary — pipeline lifecycle interruption ownership — 2026-09-26

Outcome: failed recording starts now detach page/frame and new-page topology
immediately after entering terminal error, while retaining the delivery owner
needed for `stopRecording()` to retry buffered observations. Cleanup and reset
reuse the same topology-detach helper, reducing duplicated lifecycle teardown.

Evidence: the focused pipeline-manager regression passed 4/4 and proves both
listener detachment and a clean retained-owner stop; the recording unit cohort
passed 162/162; typecheck passed; focused lint passed with 0 errors and the
three existing explicit-return warnings in `pipeline-manager.ts`; lifecycle
integration cohort passed 5/5 (rejected-event retry, uncommitted delivery,
final-input flush, admitted start/stop overlap, dynamic frame). Contract check
passed with 17 required outcomes and 24 preservation journeys.

Qualification: one managed restart completed healthy. Rehabilitation evidence
run `20260926-141425-1440e7f2` failed closed because seven owner receipts did
not match the live build `sha256:2f5c68be92edb09cddbbb6c603a58dd05427635fe47e3379550904318ad0c1e2`;
the setpoint read `prog_f5049ac0-6fbc-40dc-9ed3-fefa821909a5` reported 0/17 and
`product_qualified=false`. This is stale qualification evidence, not a product
regression. Adversarial review found no cross-generation delivery path after
the detach change. Remaining risk: current-build native receipts and
long-running browser interruption cohorts remain unverified.

## Epoch summary — session teardown and recording recovery ownership — 2026-09-26

Outcome: controlled-session close and reset now join the background
`pipelineReadyPromise` after any admitted recording stop and before browser
mutation/disposal. This prevents verification from continuing against a closed
page/context without adding a parallel lifecycle registry. External targets
retain detach-only teardown and do not wait on readiness because their renderer
and context remain owner-controlled.

Root cause evidence: a deferred-readiness regression failed before the repair
because close disposed the page while pipeline verification was still pending.
The retry-stage hypothesis was rejected as a new defect; the existing fault
matrix preserved stop/acknowledgement, buffer retention, completed-stage
retries, and eventual context disposal.

Validation: manager 71/71; full session cohort 186/186 with one existing skip;
record-mode/page-route cohort 155/155; typecheck passed; focused lint passed
with 0 errors; targeted diff hygiene passed; contract preparation passed with
17 required outcomes and 24 preservation journeys. The full session Jest run
reported an existing open-handle warning after its green terminal result; no
test assertion failed.

Qualification: one managed restart completed healthy. Exact evidence phase
`20260926-142739-ef55616b` failed closed on seven stale/missing owner receipts
for live build `sha256:5cf198104fd1cd5980f0452a29e395756bcd59913c4c87c180e87a49e3487f59`;
the governed setpoint `prog_5a54a348-bd82-4eb4-8ff1-51038c14e3ea` reported
0/17 and `product_qualified=false`. This is an evidence freshness limitation,
not a product assertion failure. Native targets, current owner receipts, and
long-running browser interruption cohorts remain unverified.

Next candidate: continue the foundation lane with current-build evidence-owner
refresh only where an authorized producer is runnable; otherwise begin a fresh
adversarial audit of recording/page callback and frame-stream ownership. Keep
BAS-FB-036 test-code quality open until a measured consolidation opportunity
appears.

## Epoch summary — frame transport replacement ownership — 2026-09-26

Outcome: WebSocket `open`, `close`, `error`, and delayed reconnect callbacks
now mutate state only when their exact socket remains the active instance. A
replacement cannot be marked unready or trigger an extra reconnect, reducing
transport churn without adding a registry or changing normal reconnect/stop
behavior.

Evidence: the pre-fix replacement regression reproduced socket A clearing ready
state and creating socket C after socket B was ready. The repaired WebSocket
owner passes 5/5; full frame-streaming units pass 68/68; managed-browser preview
close/reset pass 2/2; typecheck, focused lint, targeted diff hygiene, and
contract preparation (17 outcomes / 24 journeys) pass. Adversarial review found
no stale callback path remaining in the manager; page/source fencing remains in
the strategies.

Qualification: one managed restart completed healthy. Exact evidence phase
`20260926-143417-bf065a16` failed closed on seven stale/missing owner receipts
for live build `sha256:f4a32a5b12e1e4286dc8cabcf8fb3af6f820940fde8df83e26541d5916ee3ee9`;
the governed setpoint `prog_30c2112f-b8ed-4005-a87d-eb92c1034b86` reported 0/17
and `product_qualified=false`. This remains evidence freshness limitation,
not a product assertion failure. Current frame owner receipts, native targets,
and long-running reconnect cohorts remain unverified.

Next candidate: audit the page-event callback owner and frame strategy handoff
together for stale publication across tab replacement, while keeping
BAS-FB-036 test-code quality open for measured consolidation.

## Epoch summary — page callback cleanup ownership — 2026-09-26

Outcome: unpublished popup admission now rolls back the page registration that
it created, while preserving a stable registration already owned by the session.
Cleanup can no longer leave a detached popup in session topology for later frame
selection; created/navigated/closed ordering and explicit-tab identity remain
unchanged.

Evidence: the pre-fix cleanup regression reproduced one stale page and ID mapping
after a pending `opener()` settled. The repaired page-event owner passes 20/20;
adjacent recording-page tests pass 43/43; frame-streaming units pass 68/68;
typecheck, focused lint (0 errors, 8 pre-existing warnings), targeted diff
hygiene, and contract preparation (17 outcomes / 24 journeys) pass. Adversarial
review found the strategy handoff already fences page/source identity and
generation, so no strategy change was necessary.

Qualification: one managed restart completed healthy. Exact evidence phase
`20260926-144004-34362620` failed closed on seven stale/missing owner receipts
for live build `sha256:3f2a77d74961fedde734359bc1b5dcfe0a438d46b44afcdc3a55c1d9c613a57d`;
the governed setpoint `prog_eb287f7e-30b1-4b16-ac1f-7979d1d143d0` reported 0/17
and `product_qualified=false`. This remains an evidence freshness limitation,
not a product assertion failure. Current owner receipts, native targets, and
long-running tab/frame cohorts remain unverified.

Next candidate: audit frame-manager strategy fallback after a failed screencast
start for stale capture ownership or duplicate transport publication, while
keeping BAS-FB-036 test-code quality open for measured consolidation.

## Audit outcome — frame strategy fallback ownership — 2026-09-26

No source change warranted. Hypothesis A is covered by the CDP regression
`disposes protocol and polling resources when initial screencast start fails`:
the failed start detaches its CDP session and leaves no timers before manager
fallback. Hypothesis B is covered by manager lifecycle regressions for late
capture disposal, stopped support probes, replacement coalescing, and all-
strategy failure; each prevents stale startup ownership from publishing or
remaining active. The full frame-streaming cohort remains 68/68, with typecheck,
lint, and contract preparation already clean.

Next candidate: inspect the frame producer's backpressure/pending-frame
coalescing boundary for stale buffered delivery after a source or WebSocket
replacement, while keeping BAS-FB-036 test-code quality open for measured
consolidation.

## Audit outcome — pending frame and transport replacement — 2026-09-26

No source change warranted. The intentional reconnect path delivers the newest
buffered frame through the replacement WebSocket, while source/page replacement
rejects the old tuple and stop clears both pending data and its deadline. The
focused adversarial subset passed 13/13, covering lease invalidation,
reconnect, queue backpressure, queued page probes, ACK cleanup, generation
replacement, and stop-time deadline cancellation. The full frame cohort remains
68/68 from the prior qualification boundary; no new defect or debt reduction was
identified, so no qualification cycle was repeated.

Next candidate: rotate to a different ownership surface—recording input or
executor output backpressure—after checking current BAS-RF references and
test-code quality opportunities. Keep BAS-FB-036 open; do not create a
score-neutral helper-only epoch.

## Epoch summary — live input teardown ownership — 2026-09-26

Boundary: `playwright-driver/src/routes/record-mode/recording-input.ts` and
session reset/close owners. Preserve per-page FIFO, adjacent move coalescing,
bounded overflow, stable input-ID receipts, pointer/key recovery, and lease
admission. BAS-RF-020 explicitly leaves server-side cancellation open; the
architecture names the missing guarantee as cancellation ownership.

Hypothesis A: reset or close can begin browser mutation/disposal while an
admitted input queue item is still inside Playwright, allowing a late input
effect against a reset/closing page. Discriminator: hold a live input operation,
start reset/close, and verify lifecycle browser effects wait for input settlement.

Hypothesis B: after lifecycle invalidation, queued inputs on the retained page
can survive into the next operational lease or leave pointer/modifier state
owned by the prior lease. Discriminator: old queued work is rejected without a
browser effect and the next admitted input starts with clean ownership state.

Repair: `PageInputQueue` now owns one in-flight drain promise; reset and close
await that existing queue across all session pages before browser mutation or
disposal. Once lifecycle invalidation begins, queued work rechecks phase/lease
and rejects without a browser effect. FIFO, adjacent move coalescing, bounded
overflow, stable input IDs, and the existing transport path remain intact. The
old unjoined page-scoped queue path is gone; no second queue, registry,
dependency, or compatibility shim was added. This is a correctness ownership
repair, not a line-count reduction.

Evidence: the manager regression was red before the source integration (2/2
lifecycle joins), then passed with record-input 32/32, manager 72/72, record
routes 165/165, and frame-streaming 68/68. TypeScript, focused ESLint, diff
checks, and the refactor contract preparation check were clean. One managed
restart completed healthy with build
`sha256:f28fb9bd319747d3c3e73843851aa2a918ca66e0c3ee10317815afc40c653bd9`.
The exact rehabilitation phase
`20260926-145418-5bb4b76e` failed closed on seven stale/missing owner receipts,
with no product assertions; the governed setpoint read
`prog_5ddfe1fc-cf4a-49c3-b846-b07b1a1d04ba` recorded 0/17 readable and
`product_qualified:false` because its workload receipt was for a prior build.
Restart count: 1. Exact evidence phases: 1. Setpoint reads: 1.

Unverified: current owner receipts, native targets, server cancellation during
long browser waits, and native input semantics. BAS-FB-036 remains open.
Next candidate audit: recording output/backpressure and sink lifecycle. The
current tree already has the RF-021 repair: the UX collector flushes its own
buffers and propagates `CloseExecution`, while `WSHubSink.CloseExecution`
stops admission, drains accepted queue entries, and only then notifies the
hub. Late publishes are rejected and the queue is removed. Maintained owner
tests passed `go test ./automation/events ./services/uxmetrics/collector
./services/workflow` (all green). No source change was justified, so no
qualification or restart was performed for this audit. BAS-FB-036 remains
open; continue with a measured key/modifier lifecycle or another concrete
backpressure discriminator.

## Epoch summary — pointer/key recovery ownership — 2026-09-26

Boundary: `playwright-driver/src/routes/record-mode/recording-input.ts`, its
maintained owner tests, and reset/close state cleanup. Preserve ordered input,
lease admission, stable receipts, motion coalescing, and browser semantics.
Affected contract journeys: input ownership and cancellation/recovery;
BAS-RF-020 remains the defect register. BAS-FB-036 remains an explicit
cross-cutting constraint: any test cleanup must reduce measured duplication or
drift, not add a helper-only epoch.

Confirmed root cause: a failed pointer-up left `pointerDownPages` true, so the
finally block intentionally kept modifiers held even though the button
transition did not complete. The logical ownership bit therefore suppressed
modifier recovery and could leak across the retained page's next lease.

Repair: failed pointer-up now clears uncertain logical button ownership so the
existing finally path releases modifiers. Reset now joins the existing page
input drain and invokes one `resetPageInputState` owner to release retained
modifiers and clear page-local state before a retained page changes lease. No
second input transport, parallel state machine, registry, dependency, or
compatibility shim was added. This is a correctness repair; it does not claim
full native button recovery when the browser reports an uncertain effect.

Evidence: the required red regression failed before the fix with zero modifier
release calls, then passed. Complete record-input tests passed 34/34; manager
tests passed 72/72; affected record-mode, recording-lifecycle, and page-event
tests passed 237/237. The session-reset route passed 5/5 with its explicit
12-second Jest timeout; the default 5-second limit is too tight for this
existing managed mock reset path (about 5.0–5.7 seconds), so no assertion or
product timeout was weakened. TypeScript, focused ESLint, diff checks, the
isolated input regression, and contract preparation passed.

One managed restart completed healthy. Live build:
`sha256:2092f9cce8cafc1c414dc9fd0e66ac0decf2dd0ee357f6627fad5a7301f9af58`.
The exact rehabilitation phase
`20260926-150718-e409472c` failed closed on seven stale owner receipts with no
product assertions. The governed setpoint
`prog_bf1e4571-81db-4529-b2a0-80217f177843` recorded 0/17 readable,
`product_qualified:false`, and candidate freshness true; retained receipts
belonged to prior builds. Restart count: 1. Exact evidence phases: 1.
Setpoint reads: 1.

Remaining: full UI reload, server cancellation during long browser waits,
native input/button semantics, retries after receipt eviction, and current
owner receipts. BAS-FB-036 remains open. Next candidate: broaden the input
ownership audit to the executor keyboard/gesture state boundary, or select the
next concrete evidence-backed foundation defect; do not create a helper-only
test epoch.

## Epoch summary — executor keyboard/gesture held-state ownership — 2026-09-26

Boundary: `playwright-driver/src/handlers/keyboard.ts`, gesture/interaction
state owners, and their existing executor tests. Preserve typed-action
semantics, action ordering, retry uncertainty, and page/session lifecycle.
Relevant BAS-RF-020 residual: key/button recovery beyond tracked live-input UI
buttons remains unqualified. BAS-FB-036 remains open; test changes must prove
behavior or measured drift reduction.

Confirmed root cause A: a rejected executor key-down was recorded in
`heldKeys` only after the awaited browser call, so an effect that had reached
the browser could strand a key without cleanup. A second root cause was that
`GestureHandler.execute` returned async drag/swipe work without awaiting it,
so its outer error owner could not catch rejected pointer-release work.

Confirmed root cause B: the singleton executor handler kept page-key state in a
private map with no retained-page reset hook, despite the server's claim that
handlers are stateless. Gesture and interaction-state audits found existing
pressed-state cleanup and no additional stale owner.

Repair: key-down now records before awaiting and performs one best-effort key-up
on uncertain failure; keyboard-held state is one page-owned module map with an
explicit reset owner that releases every held key before clearing it. Reset
invokes that owner alongside the existing live-input cleanup. Gesture dispatch
now awaits its handlers, and drag/swipe share one `withHeldMouse` owner that
attempts recovery after uncertain down, movement, or release. Keyboard cleanup
no longer throws from inside `finally`, avoiding cleanup-error masking. No
second transport, registry, dependency, or compatibility path was added.

Evidence: red key-down and drag-release regressions failed before repair, then
passed. Handler units passed 27/27; keyboard/gesture integration paths passed
30/30; manager passed 72/72; record-input passed 34/34; session-reset passed
5/5 with its explicit 12-second Jest timeout; TypeScript, ESLint, diff checks,
and the input regression/contract preparation checks passed. One managed
restart completed healthy with build
`sha256:668c083c6d48cca17e478b887bbf1bc436a4330bacda320beebd0acedb4b5af9`.
The exact rehabilitation phase
`20260926-151823-f7f9b392` failed closed on seven stale owner receipts with no
product assertions. The governed setpoint
`prog_eeb7273a-b4aa-4e37-abe7-e4944843a7fa` recorded 0/17 readable,
`product_qualified:false`, and candidate freshness true; retained receipts
belonged to prior builds. Restart count: 1. Exact evidence phases: 1.
Setpoint reads: 1.

Remaining: native OS input, full UI reload, server cancellation during long
browser waits, receipt eviction, native button semantics, and current owner
receipts. BAS-FB-036 remains open. Next candidate: audit another concrete
cross-owner input/lifecycle boundary or measured evidence-backed foundation
defect; do not create a helper-only test epoch.

## Epoch summary — AI navigation lifecycle ownership — 2026-09-26

Boundary: an in-flight AI vision navigation must be stopped and joined before
reset or close mutates/disposes its page. The red manager regression reproduced
the defect: both lifecycle paths reached browser effects without invoking the
background agent owner. The red route regression then established the required
abort-and-settle contract.

Repair: `SessionState.aiNavigationCleanup` is one explicit lifecycle owner.
The AI route retains the fully finalized navigation promise, aborts the exact
matching active navigation, and clears only its own registration. Reset and
close invoke and await the hook before page/browser effects. Existing abort,
resume, callback, lease, and vision-agent contracts remain unchanged. No second
transport, registry, polling loop, dependency, compatibility path, or obsolete
caller was added.

Evidence: SessionManager passed 74/74; session-AI-navigation, session-reset,
session-run, and vision-agent suites passed 86/86. TypeScript, targeted ESLint,
diff hygiene, contract preparation, and the isolated input regression passed.
The first combined run exposed a real optional-hook scheduling regression; a
conditional call removed the unnecessary await and the full manager suite then
passed without weakening assertions or timeouts.

Managed restart completed healthy on build
`sha256:2707a7388aa1e4b42f602654f6066a6708d5ab5d7031bffce2d313ae56f8a4b4`.
Exact phase `20260926-153529-4618fa3c` was run and waited exactly once; it
failed closed on seven stale current-build owner receipts and made no product
assertions. The governed setpoint
`prog_86f8bd99-8d59-4fe5-bb41-f0ccd008956e` was read exactly once: 0/17
readable, candidate freshness true, `product_qualified:false`; the retained
capture receipt belonged to the prior build. Implementation is proven by the
focused owner checks; sensor readiness and candidate qualification remain
unverified.

Adversarial review found no second lifecycle owner, stale registration delete,
late page effect, assertion weakening, or new debt path. Restart count: 1;
exact evidence phases: 1; setpoint reads: 1. BAS-FB-036 remains open. Next
candidate: repair or refresh the highest-priority current-build evidence owner
without conflating stale receipts with a product regression, or investigate the
next concrete cancellation/teardown boundary. Native OS/device behavior,
receipt eviction, long cancellation, and current owner receipts remain
unverified. No commits were made.

## Epoch summary — artifact evidence ownership — 2026-09-26

Boundary: screenshot-write failure, inline telemetry snapshot failure, missing
external video/trace storage, and active-evidence export deletion must remain
explicit, attributable, hashed, and protected. The four-test
`evidence-completeness` producer passed all named owner tests and wrote
`evidence-completeness-2026-09-26T15-43-43-782Z-74818654.json` for managed build
`sha256:2707a738…`, with two hashed raw artifacts.

The full execution-writer and retention race cohorts passed; source-binding and
profilevalidation race tests passed. No product artifact contract changed, no
parallel evidence registry or assertion shortcut was added, and no product
contradiction was found. The exact phase
`20260926-154419-5a3867aa` was run and waited exactly once; it recognized
evidence-completeness at L1 Verified but failed closed on five unrelated stale
owner receipts. The governed setpoint
`prog_213cbe57-1a19-47d1-9445-ba253756d5bc` was read exactly once and returned
0/17 readable, fresh candidate, `product_qualified:false`. This owner’s
implementation and sensor receipt are proven; aggregate qualification remains
unavailable.

Adversarial review found no missing named test event, unbound raw artifact,
retention deletion bypass, or source/build identity mismatch. Counts: zero
managed restarts/rebuilds, exact evidence phases: 1, setpoint reads: 1.
BAS-FB-036 remains open. Next candidate: current profile durability, passive
fidelity, resource, motion, and interactive owners as one bounded evidence
foundation batch, or return to a concrete product ownership defect if a
producer reveals one. Native/device behavior and aggregate qualification remain
unverified. No commits were made.

## Epoch summary — current-build cancellation/recovery owner — 2026-09-26

Boundary: J07 timeout, driver death, accepted cancellation, API restart, and
retried start must retain one independent uncertain effect, release resources,
and deny unsafe replay. The maintained producer ran its Go execution owners,
real-Chromium retry owner, API-restart owner, and receipt assembler; it wrote
`cancellation-recovery-2026-09-26T15-38-33-255Z-ab89d274.json` for the live
build.

All five cases retained one external effect, released resources from 1 to 0,
retained uncertainty, and denied retry. API restart recovery measured 4,234ms;
its input-stop observation was 126 seconds and remains explicitly measured,
not silently promoted into a pass band. Source-binding and receipt-validator
race tests passed. The prior AI-navigation reset/close ownership regressions
also remained green. No product assertion or producer contradiction was found;
no parallel cancellation transport, receipt shortcut, assertion weakening,
dependency, or stale-receipt reuse was added.

Qualification: exact phase `20260926-154138-4caadbf9` was run and waited
exactly once. It recognized cancellation/recovery at L1 Verified, but failed
closed on six unrelated stale owner receipts. The governed setpoint
`prog_5175ae31-ffd9-4f96-9d18-600bfa2f22a7` was read exactly once and returned
0/17 readable with candidate freshness true and `product_qualified:false`;
its governed join did not promote the isolated L1 standing while the aggregate
phase remained failed. Implementation and this owner receipt are proven;
candidate qualification remains unavailable.

Adversarial review found the receipt's five-case completeness, independent
oracle, source/build binding, and no replay path intact. Restart/recovery
latency is the next performance question, not an assertion to weaken. Counts:
no additional managed restart in this epoch, exact evidence phases: 1,
setpoint reads: 1. BAS-FB-036 remains open. Next candidate: repair the
highest-priority stale evidence-completeness/profile/passive/resource/motion/
interactive owner as a bounded foundation slice, or investigate another
concrete cancellation/teardown defect. Native/device behavior and current
aggregate qualification remain unverified. No commits were made.
