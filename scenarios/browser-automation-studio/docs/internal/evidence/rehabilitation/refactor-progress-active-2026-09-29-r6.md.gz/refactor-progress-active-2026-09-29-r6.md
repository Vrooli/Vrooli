# Browser rehabilitation progress

This is the bounded resume projection, not a transcript. Read
[TESTING.md](TESTING.md) and its linked contract before acting. The complete
pre-compaction projection is archived at
`evidence/rehabilitation/refactor-progress-active-2026-09-28-r5.md.gz` with
manifest `evidence/rehabilitation/refactor-progress-active-2026-09-28-r5.manifest.json`.
Archives are retrieval records, never resume input.

## Current standing — 2026-09-29 UTC

- `browser-automation-studio-delivery` and `effort-supervision` are disabled;
  no workflow execution is active, and no worker, review or qualification lease
  exists. Enrollment is observation-only. Do not enable or recreate a team.
- Use the existing Prompt Manager delivery-team, Agent Manager workflow and
  Workspace Sandbox owners. Do not add a scheduler, worker-authored controller,
  Plan Manager plan, duplicate ledger or unrestricted campaign control.
- The pinned controller is worker → independent review → owner qualification
  only when review accepts; a rejected review terminates before qualification.
  Worker ceilings are 24 tool calls, 16 turns, 900 seconds and 400,000 aggregate
  tokens. Worker/reviewer grants exclude campaign controls, evidence roots,
  lifecycle/restart and qualification effects. Implementation and review use
  `networkMode: none`; qualification retains explicit owner grants.
- The worker continues through the admitted boundary's semantic exit gate;
  compaction, a test, or one repair is only a checkpoint, not a new epoch.
  Review has no node-local turn cap but remains under the aggregate workflow
  limits (2,400 seconds, 28 turns, 400,000 tokens, three children and one
  concurrency). Owner accounting is required; unknown usage is not zero.
- Authoritative measured policy is `gpt-6-luna`/medium for delivery and
  `gpt-6-sol`/medium for supervision. A stale partial catalog showing 5.6 is
  not evidence that GPT-6 is unavailable; the live `/usr/bin/codex` catalog and
  policy validation confirmed both GPT-6 routes on 2026-09-28.
- Shared generated-artifact freshness is a lifecycle obligation. The owning
  verifier passes:
  `cd packages/proto && GOTOOLCHAIN=local GOPROXY=off go run -mod=mod ./cmd/protogen verify`.
  This validates the source/generated contract, not BAS runtime qualification.
- The last fresh managed BAS build is
  `sha256:9125db30fde119a5fe6b169a9ad295873be5e77183e9489b630a6504015029b8`.
  The current setpoint read is stale (`readable=0`, `unavailable=17`,
  `qualification_bound=false`) because the managed API freshness check detects
  a changed `api/services/vision/playwright_navigator.go` since that build.
  Do not rebuild until E01's semantic exit and simplification gate is accepted;
  no qualification receipt exists.
- Live rehabilitation evidence is empty (0 files/0 bytes/0 lines). Superseded
  evidence is archived and the campaign guard passes. Never turn a stale build,
  timeout or historical receipt into qualification evidence.
- A current-source focused rerun on 2026-09-28 passed 79/79 across the
  navigation, conversation, Recording API and vision-navigation cohorts;
  `REQ:BAS-RH-J24` covered 45/45 tests. `pnpm exec tsc --noEmit` also passed.
  These checks exercise the current source only and do not refresh the managed
  build or create qualification evidence.

## Active candidate epoch E01 — navigation observation and managed shutdown

Candidate state: **implementation**

Qualification cycle: **unused**

This single ownership boundary covers status-wait cancellation, authoritative
navigation transitions, managed restart cleanup, driver/browser teardown,
BAS-RF-148, BAS-RF-149, BAS-RF-017 and measured simplification. The worker
cannot choose or close the boundary, edit this file, rebuild/restart managed
BAS, run evidence producers, qualify, or issue the setpoint.

## Verified evidence

- UI `record-mode` passes 643/643; the latest focused navigation,
  conversation, Recording API and vision-navigation cohort passes 79/79.
  UI type-check and scoped lint pass (only two existing non-null assertion
  warnings in `actionDisplay.test.ts`).
- API-core shutdown, BAS navigation, vision/redaction and sidecar-supervisor
  suites pass with race detection. Driver manager passes 75/75. Generated
  verifier passes. These are source-level checks, not managed qualification.
- Status transport loss is non-authoritative `observation_unavailable`; a
  regression proves one assistant message survives loss and terminal recovery
  without duplication. A separate cancellation controller fences terminal,
  handoff, replacement-observation and unmount paths; focused
  `REQ:BAS-RH-J24` coverage is 45/45 in the latest focused rerun.
- Conversation lifecycle projection now has one ordered message-patch effect
  instead of three competing effects. The current hook fell 341→333 lines;
  targeted ESLint and TypeScript checks pass, and the focused 79/79 cohort
  remains green. This is a local ownership/render reduction, not whole-E01
  acceptance.
- Status observation now has an explicit `aborted | unavailable | received`
  transport result. API exception/result decoding is outside the lifecycle
  snapshot owner, which removes its branching hotspot without changing the
  recovery fence. The focused cohort remains 79/79; the navigation start
  response-to-identity commit is now its own named boundary, removing the
  start-command complexity hotspot without changing admission fencing. Start,
  abort and resume command ownership now lives in
  `useAINavigationCommands.ts`; the enclosing hook retains event, recovery and
  state composition. Abort/resume now share one handoff request/failure path,
  so command admission and failure cleanup have one owner. Focused ESLint is
  clean and the focused cohort remains 79/79 with typecheck passing. The stable
  command-ref aggregate now uses one ref instead of a dependency-heavy memo;
  the public-hook-plus-command surface is now 489 lines versus the original
  631. `useAINavigationRuntime.ts` owns the shared identity/cancellation refs,
  reset lifecycle and command/event contract, leaving the public hook as a
  composition boundary. The complete navigation surface is 1,179 lines versus
  1,160 before this extraction: the command/runtime owners still have measured
  cohesion warnings (124 and 84 lines against the local 60-line threshold).
  Focused 79/79 and TypeScript pass; this is a verified ownership improvement,
  not E01 acceptance, and the full-surface delta must be reduced or justified.
- Orphan recording cleanup now has one keep/protection/order/byte-cap owner:
  `owner_cleanup.go` fell 879→871 lines and gocyclo 224→219. This is a local
  measured reduction, not whole-BAS acceptance.
- Navigation parsing has one dispatcher and shared scalar/enum/field readers;
  action-field complexity fell 15→5. The unused legacy AI-navigation schema
  family (169 lines) and unused UI interfaces were removed after repository-wide
  consumer searches. Navigation/event/lifecycle are exclusive owners, but the
  complete surface is now 1,179 lines; the extra runtime owner and its evidence
  obligations still require a measured full-surface reduction or explicit
  irreducibility rationale.
- Runtime inventory including untracked source is 283,112 lines versus 284,443
  baseline (-1,331), while API runtime Go gocyclo is 16,539 versus 16,405
  (+134). Recent additions include evidence-completeness validation (+63),
  privacy redaction (+49), profile validation (~25), sidecar lifecycle (+17)
  and small helpers; cleanup/cancellation reduced other surfaces. Size alone
  cannot accept E01.
- Gate audit on 2026-09-29 compared the tracked 631-line UI baseline with the
  current owners: neither baseline nor current owner has a custom complexity
  warning, while the main and command hooks each retain a 138-line function
  cohesion warning against the local 60-line threshold. The protected global
  ratchet is only one unit below each baseline dimension, so it is not material
  whole-surface debt proof. The first bounded tidiness attempt exposed a stale
  API registry row; managed `make restart` restored the API. The next attempt
  exposed a shared CLI/API duration wire mismatch, which was repaired at the
  CLI transport boundary with regression coverage. The bounded smart scan now
  passes for one current navigation file (0 findings); this validates the
  owner gate, not BAS qualification.
- Interrupted owned-page teardown snapshots page/video handles before close and
  does not close external-target pages; `manager.test.ts` is 75/75. Recovery,
  export privacy, desktop/mobile/native preservation and managed restart remain
  unverified.
- Playwright step admission now rejects terminal/duplicate callbacks before
  deep redaction and reuses one sanitized action, URL and text projection for
  the retained step, recording callback and websocket path instead of
  traversing the same payload repeatedly. The full vision package passes under
  race detection; this is a local performance/ownership simplification, not
  whole-E01 acceptance.
- The AI-navigation architecture and invariant registries now document the
  actual callback normalizer, UI observation/event/lifecycle owners,
  `observation_unavailable` recovery contract, one-projection redaction rule,
  successor admission fence and managed-cleanup boundary. Source hash
  preconditions passed; knowledge retrieval/reference verification remained
  partial because the documentation index returned no post-edit text result
  and the existing scenario-wide reference baseline contains unrelated legacy
  warnings. This is maintainability guidance, not runtime evidence.
- The event-versus-recovery review found no lossless single projection: WebSocket
  events are incremental and low-latency, while status snapshots carry
  authoritative recovered detail and terminal identity. Their shared
  navigation/generation refs remain the fence; command admission and handoff
  failure cleanup are already centralized. This is a documented ownership
  decision, not permission to add another adapter or count file movement as
  simplification.
- Agent Manager terminal accounting, Workspace Sandbox finalization/recovery,
  generated-artifact preflight and owner-level finite token/charge caps were
  repaired and focused tests pass. These are shared-infrastructure repairs, not
  BAS product qualification. The standing Sol grant remains authorization-only;
  no child run or settlement receipt has been admitted.
- Tidiness-manager is healthy after a managed restart, and its CLI transport
  decoder now accepts both the API's numeric `time.Duration` JSON and the
  human-readable string form. The focused CLI suite passes; the bounded smart
  scan completed with one file analyzed and zero findings. Scenario-wide
  tidiness remains unmeasured. CLI `golangci-lint` remains unverified because
  the installed Go 1.25 toolchain cannot type-check a vendored package that
  requires Go 1.26. Managed restart timing, recovered/export privacy,
  diagnostic-probe ownership and whole-surface simplification remain open.

## Required next boundary work

1. Continue the parser/lifecycle simplification review. Remove duplicated
   transitions or justify recovery surface with a comparable metric; preserve
   cancellation and overlap tests. Do not count wrappers, file movement or test
   churn as debt reduction.
2. Refresh this projection only with changed, verified, remaining and
   unverified facts. Keep live evidence under campaign-guard limits; archive a
   dated compressed cohort with manifest before any broad producer run.
3. When the semantic exit and measured-simplification gates pass, freeze the
   candidate and obtain independent review. Only then may the existing owner
   controller issue its one-use worker → Sol review → qualification lease.
4. Do not spend the standing grant without a concrete target and current
   settlement path. A wake count, profile turn limit, timeout or provider
   estimate is not aggregate economic enforcement; unresolved usage keeps
   admission disabled.
5. Resolve owner-backed review for the changed no-lifecycle row and the failed
   finalization heartbeat row; preserve proven-empty rows. Refresh only
   invalidated cohorts on a fresh owner-controlled build, run one exact
   qualification cycle/setpoint read, then perform adversarial review.

## Evidence and history

The superseded working set is retained at
`../.vrooli/runtime/rehabilitation-evidence/archive/superseded-working-set-before-e01-refresh-20260928.{tar.gz,manifest.json}`.
Earlier progress projections remain at r4, r3,
`refactor-progress-precompact-2026-09-28.md.gz` and
`refactor-progress-stopped-2026-09-27.md.gz`. This mandate remains active until
the operator stops or redirects it.
