# Browser rehabilitation progress

This is the current resume packet, not an execution transcript. Read
[TESTING.md](TESTING.md) and the referenced open findings only. The operator
stopped the unrestricted BAS agent. Do not resume it or run qualification from
the historical epoch labels.

## Current standing — 2026-09-28 UTC

- Delivery team: `browser-automation-studio-delivery`, disabled and
  multi-process/serialized; revision 3 records the owner-backed shape and its
  disabled finite-leader binding uses `prompt-manager/delivery-coordinator`.
- Accepted candidate / last accepted ownership boundary: **not established**.
  Earlier worker-declared “frozen” and “closed” epochs are historical claims,
  not independent acceptance.
- Qualification admission: **none**. The old campaign guard is diagnostic;
  worker-editable Markdown cannot grant a rebuild or qualification. The
  owner-controlled `qualify-candidate` malformed-admission fixture has passed
  with `invalid_input` before any effects; this is refusal proof, not a live
  qualification or accepted candidate.
- Integration owner: existing PM delivery teams and AM effort supervision.
  Read only the current checkpoint in
  [effort-supervision-validation.md](../../../../docs/agent-system/effort-supervision-validation.md).
  That checkpoint owns integration status; this file owns BAS product standing.
- Enrollment has only the disabled coordinator; do not recreate team/catalog
  state. Continue from the salvage boundary and pilot gate.
- The protected owner lifecycle file passes raw validation at digest
  `sha256:9fbf6373c415e749ec082a05422bbf7185e749625dae3c8bf346d5381b4a15c7`;
  declaration reconciliation resolved and registered the effective pinned
  active revision at
  `sha256:96b76a8ba152a898d3e55056ef16ddf412148de44c18070e4347b536dadfd5ec`.
  The effective revision is the dispatch identity. Worker and independent-review
  instructions are scenario-owned contract skills with no mature-rung inline
  prompt warnings. No run starts here; Agent Manager rebinds retained-candidate
  identity before review and qualification.
- Preserve source; never reset or commit user changes. On 2026-09-28 the owner
  reconciled stale run `79d77358-74fa-4193-9a59-22b10b7cae71` (last heartbeat
  2026-09-16; zero sandbox processes/files) and stopped its empty sandbox;
  Agent Manager now reports no active runs. This repaired shared state only;
  it is not BAS acceptance or permission to dispatch.
- BAS-FB-047 is open: the operator reports eight hours and one quarter of weekly
  usage spent on setup without a completed pilot. The integration checkpoint
  owns the corrective efficiency, requested-model and simplification standing.
- The BAS reconnect pilot (`4eb2e9f8-2d5c-4cab-bd01-b4f505b64d78`) completed its
  Luna worker (`b7796a43-11f9-4539-b872-86632f690fcd`) but review dispatch failed
  before Sol launch: the workflow had supplied project-relative review paths to
  a scenario-scoped sandbox. The source now uses sandbox-relative paths and
  Agent Manager preflights this contract; focused orchestration tests pass.
  Direct capture with the corrected paths succeeded for the retained two-file
  candidate. The old execution is terminal budget-exhausted and is not an
  acceptance result; do not replay it.
- Shared contract hygiene is now repaired at the package owner rather than in
  Test Genie: scoped generation includes imported owners, changed runs verify
  recorded output digests, and fleet cleanup removes orphan owner footprints.
  `protogen verify` passes after removing the retired template-validation
  generated tree. Package-target tests now preflight declared generated-owner
  lifecycles, so this protection is not Test Genie-specific. This is
  infrastructure proof only; it does not qualify BAS. Direct ad-hoc module
  tests still bypass the control plane and must run the owner's verifier first;
  that limitation is now explicit in the repository testing contract.
  The Test Genie API module now compiles against the refreshed generated
  validation contracts; its remaining full-suite failures are unrelated
  catalog/provider/documentation fixtures, not missing generated types.
  All shared model-policy consumers now use the live catalog authority marker;
  stale compatibility-cache data is refused as availability proof, so neither
  policy validation nor the drift safeguard can independently misclassify
  GPT-6 as absent.
- The failed pilot's missing hard-stop seam is now repaired in the shared
  Agent Manager runner: workflow run/continue nodes may declare an owner-only
  `maxToolCalls` ceiling, it is persisted in the resolved run configuration,
  and both streaming and durable-transcript runners kill the process and emit
  a typed execution failure at the ceiling. The pilot definition is bounded
  at 24 worker calls/16 turns and 900 seconds, with a 400,000-token aggregate
  workflow budget. Focused core, workflow-catalog and child-launcher tests pass;
  Agent Manager's managed restart reconciled this source and the
  active workflow revision is now
  `sha256:96b76a8ba152a898d3e55056ef16ddf412148de44c18070e4347b536dadfd5ec`;
  worker, review and
  qualification budgets are each three.
- After hard-stop and scope changes, source validates at digest
  `sha256:9fbf6373c415e749ec082a05422bbf7185e749625dae3c8bf346d5381b4a15c7`;
  active revision still requires the owner-controlled pilot gate.

- The earlier post-repair pilot failed pre-effect on a root-relative grant;
  shared accounting records proven zero usage. Do not rerun it.
- The next disposable pilot (`94982dbc-77c7-479c-b4d1-493a30a6f4d1`) launched
  `gpt-6-luna` but failed during refresh without a receipt; it is closed as
  `accounting_unknown` and must not be retried.
- Pilot `56a51d70-99bd-45da-bb12-4866fdd9da2b` resolved `gpt-6-luna`, measured
  13,314 tokens, made no change because its grant was not surfaced, and hit
  `maxNodeAttempts:1` before review. The shared network-policy split is fixed.
- Replacement pilot `74da73d8-5911-4198-911b-103af39125c7` proved worker
  `gpt-6-luna` and review `gpt-6-sol` both used native `none`/outer `localhost`;
  review rejected the empty candidate. It consumed 252,027 tokens; prior
  budget exhaustion prevented qualification. Active budget is now three; do
  not rerun this refusal fixture.
- Scope-corrected pilot `473e8891-ec9e-4e06-9e04-66c3191bc299` inspected the
  UI owners but made no justified change; Sol again rejected the empty snapshot.
  It consumed 213,233 tokens and exposed `maxChildren:2`; active source now
  budgets three children. Do not rerun without a real candidate diff.

## Active candidate epoch E01 — navigation observation and managed shutdown

Candidate state: **implementation**

Qualification cycle: **unused**

This is one semantic ownership boundary spanning status-wait cancellation,
authoritative navigation transitions, restart cleanup and driver/browser
artifact teardown. It remains active across compactions; the salvage review,
not the worker, decides when its exit gate is met. BAS-RF-148 and BAS-RF-149
must pass their runtime checks, BAS-RF-017 must retain its privacy proof, and
obsolete paths must be removed with measured net simplification before this
epoch can be frozen.

## Salvage review — not yet accepted

A bounded, read-only Sol-medium review inspected the modified/untracked BAS
product sources and tests, plus BAS protocol source/generated deltas. It ran
no tests, browser workflows, services, or qualification. “Retain” below is a
source-review recommendation, not proof of runtime correctness or permission
to accept the candidate. Narrative and historical evidence received presence
checks only. This review is not the managed Luna → Sol pilot.

The current strong-model salvage disposition is retained at
[`evidence/rehabilitation/salvage-review-2026-09-27.md`](evidence/rehabilitation/salvage-review-2026-09-27.md).
It independently refuses acceptance: the tracked diff is 57 files and net
`+1,970` lines, `useAINavigation.ts` is 951 lines versus 631 at baseline, and
the mixed navigation/shutdown boundary still needs simplification and focused
owner proof. This disposition does not create an accepted candidate or a
qualification lease.

The 2026-09-28 reassessment at
[`evidence/rehabilitation/salvage-reassessment-2026-09-28.md`](evidence/rehabilitation/salvage-reassessment-2026-09-28.md)
confirms that the shared shutdown cleanup, observation-loss recovery, and
AI-action redaction repairs are now source/test-green. It does not change the
decision: managed restart/teardown proof, measured lifecycle simplification,
and an accepted owner-controlled candidate are still missing.

A subsequent adversarial review retains three blockers: status-wait cancellation
before HTTP drain, stale navigation identity after observation loss, and raw AI
action values/results without a proven redaction owner on every live/recovered
path. It measured `useAINavigation.ts` at 948 lines, found two obsolete probes
and a loose evidence cohort, and ran no runtime checks. Repair or falsify each
inside this boundary, then compact evidence before another pilot.

The first coherent repair boundary is **navigation observation and managed
shutdown**: status-wait cancellation, authoritative lifecycle transitions,
restart cleanup, driver/browser teardown, and the UI navigation/conversation/
sidebar/action-display owners needed for the three blockers and BAS-RF-017.
This is a recorded in-scope extension within `acceptance_allow`; include
regressions and deletion of replaced paths. A single callback repair does not
finish the boundary.

The 2026-09-28 lifecycle simplification extracted wire parsing and recovered-
state projection into `ui/src/domains/recording/ai-navigation/navigationEvents.ts`;
the lifecycle hook is now 621 lines versus the 631-line baseline. The focused
navigation/conversation/API cohort (62/62), BAS-RH-J24 coverage, UI type-check,
and targeted lint pass. This improves ownership clarity but is not a net-debt
or acceptance claim: the combined recovery surface remains larger than the
baseline and managed runtime proof is still required.

Shared owner repair completed during this checkpoint: `api-core/server` now
always invokes the cleanup callback with a fresh bounded context even when the
HTTP/custom-server drain reaches its deadline, and standard-server active
requests are force-closed so their contexts wake before teardown. The regression test passes;
BAS-specific long-poll cancellation and teardown proof remain open.
The UI observation path now preserves a live navigation identity as
`observation_unavailable`, keeps the stop control available, and prevents a
second start until the server operation is settled. Focused navigation,
conversation and sidebar tests plus UI type-check pass; a retry/reconnect UX
and end-to-end driver teardown proof remain open.

The first protected pilot was attempted and failed before review: the Luna
worker made 75 tool calls (the report's `repeated_tool_calls=73` is a
tool-name repetition count, not proof that 73 identical commands ran; 11 calls
were unresolved), reported 3,841,994 tokens against a 700,000-token owner
budget, and produced a zero-byte applied diff. Its structured handoff and exact
run evidence are retained in the integration checkpoint; no review or
qualification ran. Do not retry until the worker context/allowlist and
execution-stop gates are repaired.

The active revision now opts into metered cancellation; deterministic
qualification is admitted by the shared policy, while live samples and stop
latency remain unverified until a pilot.

The pilot exposed a launch defect: Agent Manager now forwards the admitted
sandbox network mode to `/processes` instead of silently using the
`vrooli-aware` default. The live pilot proved both nodes use outer `localhost`
for model transport while their Prompt Manager profiles keep Codex-native
command networking denied; review is protected/read-only/non-applying. Tests
pass; loopback-only enforcement remains open

Integration remains declaration-only for product acceptance. The canonical
checkpoint in [effort-supervision-validation.md](../../../../docs/agent-system/effort-supervision-validation.md)
owns supervisor limits and model routing; live catalog health confirms
`gpt-6-luna` and `gpt-6-sol`.

The immutable salvage review owns the full retain/simplify/remove table; this
packet keeps only the resume boundary and its open acceptance gates. LPBS
preservation, native/mobile/desktop behavior, browser persistence, performance,
and net complexity reduction still require the contract's proof.

## Next product checks

Focused salvage verification (2026-09-28): the current source passes the
vision-navigation, sidecar-supervisor and cancellation-qualification Go tests;
the API-core shutdown-timeout tests pass; the focused navigation, conversation,
sidebar and API UI cohort passes 94/94; the UI record-mode suite passes 56/56
(30 `BAS-RH-J24` tests); the focused cancellation/recovery and
profile-validation race owners pass; and the two selected real-Chromium
typed-action cancellation owners pass. A managed rebuild/restart then loaded
candidate `sha256:1362c26b6acc380e4a023c49b520765032a48c41623ef46bd090e2de2079b7d8`.
The bounded J07 restart owner on that same identity passed: one held external
effect, resources 1→0, uncertain terminal failure, replay denied, input stop
269.4 ms, cleanup 12.9 ms, and first terminal observation 7.23 s after the
stop boundary. Two earlier diagnostic runs are retained as failures rather
than receipts: one measured pre-stop preparation 1.685 s and one included a
stale-candidate setup rebuild. This is managed cancellation/restart evidence,
not acceptance of the salvage or the full status-wait path. BAS-RF-148 still
needs its outstanding status-wait cleanup cohort; BAS-RF-149 still needs its
managed observation-loss/recovery cohort and owner-controlled receipt.
The subsequent governed setpoint read (`prog_6c7a438d-ace6-4e95-9a0c-61b7a6ab5f53`)
confirmed this candidate is fresh, but all 17 rows are unavailable because the
phase receipts are expired or absent; it did not authorize qualification.

1. BAS-RF-148: reproduce shutdown with an outstanding status wait; require waiter
   cancellation and cleanup even when HTTP drain exceeds its deadline. Exercise
   real owner cleanup without depending on a 300-second sleep.
2. BAS-RF-149: reproduce observation transport loss followed by recovery and a
   new user request. Distinguish unknown observation from authoritative failure;
   UI state, admission and conversation messages must agree.
3. BAS-RF-017: synthetic password/OTP/token data must be absent from live action
   details and recovered status/history. The shared vision redaction boundary
   now covers Playwright callbacks, Claude Code tool streams, bounded step
   history, completion data, status recovery, recording callbacks, URLs, and
   human-intervention text. Synthetic secret regressions cover both navigators.
   The UI sidebar now adds defense-in-depth display redaction for sensitive
   selectors, credential assignments and URL query values. Its focused utility
   and component regressions pass, including a raw provider-result echo of the
   submitted secret (the edge case that assignment-pattern redaction missed).
   Passive recorder/export, managed live and
   recovered-status cohorts, and legacy at-rest paths still require separate
   qualification; recording-proto redaction alone does not cover this path.
4. Replace duplicated navigation state transitions with a cohesive owner and
   remove obsolete paths. A file split or smaller route file alone is not a
   complexity improvement.
5. Qualify only after externally reviewed acceptance and frozen content identity.
   Stale receipts are not permission to start another rebuild cycle.
6. BAS-RF-150: the owner handoff is repaired at the Test Genie seam. After WSS
   promotion, qualification resolves the exact candidate source identity via
   the read-only validation RPC before admitting evidence. Focused API, CLI,
   protobuf, and BAS composition/refusal checks pass; one protected live pilot
   remains gated on accepted salvage review evidence.

## Preserved history and evidence

The exact preceding 345-line / 16,373-byte checkpoint is preserved in
[`refactor-progress-stopped-2026-09-27.md.gz`](evidence/rehabilitation/refactor-progress-stopped-2026-09-27.md.gz).
Compressed SHA-256:
`4f4782e2d2b9d1c2ba637958036da3fa8b9269b6690b9aa7b8c3badbcaf74f70`.
Decompressed SHA-256:
`73938fef4ad9e4e87258cd0945a2f859627c83636d3047046d64ab0d0de6cb9b`.
Integrity and exact decompressed bytes were verified before replacement.
Retrieve with `gzip -cd <archive-path>` only for a decision needing history.
That record retains prior receipt IDs and links to earlier full histories;
the E16–E57 gap in the former active view was not reconstructed or declared lost.

Review-time runtime evidence: 78 files / approximately 22.9 MB overall; the
current live non-archive working set is 24 files / 5,625,807 bytes (135,486
lines). Counts are an observation, not a retention guarantee, and exclude the
archived directory. The owner-retention implementation and
focused age/byte/active-work tests pass, and deployed logs show successful
recordings/captures sweeps. Rehabilitation-cohort rotation and owner release
remain unverified. The already-archived loose cohort is now
`archive/superseded-pre-qualify-2026-09-26.tar.gz`: 27 files, 6,875,729 source
bytes compressed to 498,879 bytes. Its adjacent manifest records SHA-256,
selection and retrieval. Listing and byte comparison passed before removing
the loose copy; every file is recoverable from the archive. No live product
receipt was regenerated or removed. Automatic owner retention remains open.
