# Browser rehabilitation progress

This is the bounded resume view, not an execution transcript. Read
[TESTING.md](TESTING.md) and its linked contract before acting. Historical
chronology and raw owner payloads stay in the cited archives; do not append
tool transcripts here.

## Current standing — 2026-09-28 UTC

- Delivery team `browser-automation-studio-delivery` is disabled and serialized;
  no accepted candidate or qualification lease exists. The representative
  execution `de06300a-6060-4e31-9afe-55e3fee03a81` is terminal
  `budget_exhausted/wall_time`, not product acceptance. Do not enable or
  recreate the team.
- The existing Prompt Manager delivery team and Agent Manager workflow remain
  the integration owners. Do not add a scheduler, worker-authored controller,
  Plan Manager plan, or duplicate ledger.
- The obsolete Swarm Manager goal `browser-automation-studio-improve` and its
  pass-rate target were archived through the owner API after confirming no
  execution or queue item remained. This removes the competing setpoint loop;
  the Prompt Manager delivery team is now the sole registered BAS campaign path.
- Source workflow validation and reconciliation now pass at digest
  `sha256:b6fcbef7e31ed0284998a9a838e9518cc42712018a08ccb0e692afa67e57f60f`.
  Worker limits are 24 tool calls, 16 turns, 900 seconds, and the aggregate
  workflow budget is 400,000 tokens.
- The current source passes Agent Manager's read-only reconcile plan and a
  pinned workflow simulation: the graph is exactly worker → independent review
  → owner qualification → end, with Luna delivery and Sol review profiles.
  Simulation is admission evidence only; no provider run or qualification effect
  was started.
- Owner-validated Codex routing resolves `code.delivery` to `gpt-6-luna` and
  `judgment.supervision` to `gpt-6-sol`. Direct `/usr/bin/codex --version` is
  0.156.1 and lists both models; shared discovery resolves a Vrooli shim to
  the launch binary and records executable path/version, so a partial shim
  listing cannot be read as a missing GPT-6 model.
- Shared generated-artifact freshness is enforced at package owners. Test
  Genie is not the owner of generated code. The package lifecycle verifier and
  `protogen verify` are the source of truth before module-level tests. The root
  `make test` path now runs that verifier before compiling control-plane
  consumers, and the verifier excludes only the runtime Proto selection stamp,
  preventing both stale generated code and false drift failures.
- Package governance now rejects a generated-output declaration with no
  lifecycle generation/build owner, and lifecycle setup fails closed with a
  typed `missing-generator-contract` error before any consumer is compiled.
  This generalizes the repair beyond Test Genie and prevents future owners from
  silently becoming stale source-only projections. Repository-level generated
  owners also reuse the governed `lifecycle.requires` ordering, with a focused
  dependency-order regression green.
- The protected worker write grant and independent review snapshot now include
  the extracted `useAINavigationEvents.ts` owner and the managed recording-close
  handler/test owner. Agent Manager validation and reconciliation pass after
  this allowlist change; the worker still has no
  campaign, evidence, lifecycle, or qualification write access.
- That execution completed one Luna worker (no justified source change) and one
  Sol review, which rejected the empty candidate. Qualification then retried a
  deterministic review-authority rejection until the wall-time budget expired.
  Agent Manager now classifies typed deterministic preparation rejections as one
  durable terminal failure while preserving retry for transient owner errors;
  focused workflow-runtime and orchestration tests pass. The managed restart
  ended the old execution at its existing wall-time boundary; a fresh accepted
  pilot remains unproven.
- Control-plane restart ordering is now covered by a focused lifecycle
  regression: an explicit restart emits the stop boundary before resolving the
  engagement/source layout. The pre-fix test observed `engagement, stop`; the
  repaired path observes `stop, engagement`. This removes a potentially slow
  control-plane read from the accepted-effect cancellation window; the managed
  BAS receipt still must be rerun against a refreshed control-plane binary.
- Managed navigation exposed a separate close-order defect: a driver session
  can be terminal/absent before the public recording-close request, and the
  old handler stopped at profile persistence, leaving the active profile
  binding stale. The close path now continues only for classified terminal or
  absent-session errors, clears the binding, and returns
  `profile_persisted=false`; transient snapshot failures still preserve retry
  ownership. Focused handler, session-manager, live-capture, and
  session-profile tests pass. The refreshed managed build is healthy, and the
  profile-backed close-after-driver-loss receipt passes with binding cleanup and
  zero residual driver sessions; broader E01 acceptance remains open.

## Active candidate epoch E01 — navigation observation and managed shutdown

Candidate state: **implementation**

Qualification cycle: **unused**

This is one ownership boundary spanning status-wait cancellation, authoritative
navigation transitions, managed restart cleanup, and driver/browser teardown.
The worker cannot freeze it, choose another boundary, edit this file, rebuild
the scenario, or qualify evidence. BAS-RF-148, BAS-RF-149, and BAS-RF-017,
plus measured net simplification, must pass before a strong review can freeze
the candidate.

## Salvage review — not accepted

The read-only Sol salvage review and the 2026-09-28 reassessment are retained
at:

- [salvage-review-2026-09-27.md](evidence/rehabilitation/salvage-review-2026-09-27.md)
- [salvage-reassessment-2026-09-28.md](evidence/rehabilitation/salvage-reassessment-2026-09-28.md)

They refuse acceptance. Current source repairs are focused-test green, but
managed status-wait cleanup/restart proof, passive/export/privacy qualification,
and an accepted owner-controlled candidate are missing. The old review's
951/948-line hook measurement was stale. The current ownership surface is
`useAINavigation.ts` at 475 lines, `navigationEvents.ts` at 321 lines, and the
WebSocket event owner at 148 lines: 944 lines total versus the 631-line
baseline. The lifecycle owner is below the 500-line cohesion threshold and
the transport boundary is explicit, but the parser extraction adds 313 lines
to the measured surface. This is not yet a net-complexity reduction; moving
code between files is insufficient. The reset/session lifecycle has one reset
owner and 30/30 recovery tests plus TypeScript checking pass, but E01 remains
open until a simplification review either reduces the real surface or records
why a smaller, materially clearer ownership design justifies the added code.

## Verified source evidence

- `api-core/server` invokes cleanup with a fresh bounded context after a drain
  deadline and force-closes standard-server requests, so long polls cannot skip
  owner cleanup. API-core timeout/forced-close regressions pass.
- UI status transport loss becomes `observation_unavailable`; the live
  navigation identity and stop admission remain available, and successor start
  stays fenced until the operation settles. Navigation/conversation/sidebar
  regressions pass.
- Vision and navigation Go tests, focused cancellation/recovery race owners,
  selected Chromium cancellation owners, and `protogen verify` pass. The
  current focused UI record-mode cohort is 83/83, including 30 `BAS-RH-J24`
  cases; the focused navigation/conversation/API cohort is 94/94.
- The latest governed setpoint read found that prior candidate fresh but all 17
  rows unavailable because current phase receipts were expired or absent. It
  does not authorize qualification or prove the current source candidate.
- The retained synthetic owner probes now execute against the current session
  imports after their dependency seams were refreshed: reuse/target/evidence
  controls are 17/17 and session/frame controls are 16/16. They remain
  diagnostic owner coverage (not browser or platform qualification) and are
  not obsolete deletion candidates.
- Privacy source/UI owners and managed API/driver probes have bounded receipts;
  deployed recovered-status, legacy-at-rest and export behavior remain
  unverified until the current candidate is rebuilt and reviewed. Retain the
  cited privacy receipts as diagnostics, not qualification evidence.
- A fresh read-only salvage review was reconciled against the current tree
  before acting on it. Its shutdown/cleanup warning describes the pre-repair
  `api-core/server` path: the current owner uses an independent cleanup budget
  after HTTP drain and force-closes standard-server connections on timeout.
  Its observation-loss warning also predates the current
  `observation_unavailable` state, retained navigation identity, stop
  admission, and recovery tests. Its raw-action warning is now covered by the
  UI display-redaction boundary and synthetic-secret utility/component tests.
  These repairs are retained, not reopened as duplicate work. The review's
  remaining concerns—repeatable managed restart timing, deployed/recovered
  privacy and export/legacy-at-rest proof, and removal or ownership of
  diagnostic probes—remain open until their owner receipts exist.
- The focused UI record-mode project was rerun against this source tree:
  57/57 tests passed, including the navigation, conversation, API, sidebar,
  and action-display redaction cases (`REQ:BAS-RH-J24`, 31 cases). This is
  source evidence only; it does not qualify the managed candidate.
- The passive-fidelity three-owner refresh now passes against the healthy
  current build `sha256:0c62b8cf731ca1a68e82561d7b72114bc2eb67df4f7b3cefa81ab97899c46d46`:
  the managed Chromium/API owner recorded 10,000 effects, unique ordered
  journal IDs, 10,000 applied-input receipts, and zero primary-pool requests
  in 46.4 seconds; the recording-service process-death owner passed 1/1 with
  10,000 committed actions and same-ID retry recovery; the three selected
  browser-semantics cases passed 3/3. The assembled receipts are the
  `passive-fidelity-*-current-20260928-r1-assembled.json` files under the
  runtime evidence root. This refreshes the owner row only; the exact
  rehabilitation provider phase, native/browser expansion and E01 privacy
  gates remain unrun.
- The required read-only setpoint read `prog_921d31dd-4139-4617-8989-dce7ff941064`
  completed against the refreshed healthy build with lifecycle freshness
  true, but correctly reported all 17 rehabilitation rows unavailable: the
  exact `rehabilitation-evidence` provider phase has not been admitted and the
  current owner receipts therefore cannot be promoted to qualification by
  inference. This is an honest sensor result, not a failure of the new
  passive-fidelity receipts.
- The current source candidate was rebuilt and loaded through the managed
  lifecycle at build identity
  `sha256:75e7b3f770eb2d66d03039e23510c0791ddc44f3a712db865c1636be374e51eb`;
  the scenario returned healthy. The single outstanding-wait restart owner
  then observed one external effect, resources 1→0, cleanup 11.4 ms and
  recovery 8.99 s. It failed only the input-stop band: stop occurred 2,166.3
  ms after effect acceptance because restart preparation took 2,152.0 ms;
  stop-to-release was 11.4 ms. This is diagnostic failure evidence, not a
  qualification receipt, and is retained at
  `.vrooli/runtime/rehabilitation-evidence/cancellation-restart-owner-20260928.jsonl`.
- The shared generated-artifact boundary was rechecked after the candidate
  rebuild: `cd packages/proto && GOTOOLCHAIN=local GOPROXY=off go run -mod=mod
  ./cmd/protogen verify` passed, and the previously affected Test Genie CLI
  plus validation-broker packages compile and pass their focused tests.
  This confirms the failure class is shared Proto freshness, not a Test
  Genie-owned contract defect. Three subsequent direct managed BAS restarts
  crossed the stop boundary immediately and returned healthy; the 2.15-second
  pre-stop delay is therefore a transient still requiring attribution, not a
  reason to widen the qualification band.
- The shared-owner repair is now generalized beyond the original consumer:
  lifecycle provisioning materializes the selected immutable Proto artifact
  and writes `packages/proto/gen/.vrooli-proto-artifact.json`; canonical and
  caller-supplied Go CLI freshness contracts retain that stamp alongside
  `packages/cli-core`. Focused `cli-core` freshness/app tests, the Proto
  materialization test, and lifecycle tests pass. This keeps installed CLIs
  from silently reusing a build after the shared generated contract changes,
  without hashing the large generated tree per invocation. The repository Proto
  preflight and Test Genie CLI build guidance now name this owner boundary.
- Shared model discovery now resolves a Vrooli Codex shim to the same launch
  binary and records its path/version. The installed resource CLI was refreshed
  from that source so its live probe now returns `/usr/bin/codex`
  `codex-cli 0.156.1` with `gpt-6-luna` and `gpt-6-sol`; the earlier partial
  `gpt-5.5` result was stale installed CLI behavior, not GPT-6 absence. Policy
  validation is green and no GPT-6 downgrade is inferred from cache data.
  Shared CLI freshness now covers known non-API subcommands, including model
  discovery and policy commands, with a regression test; focused
  `cli-core/agentcatalog`, `cli-core/cliapp`, and Codex CLI tests pass.
- BAS qualification no longer accepts caller-provided lifecycle authority. The
  destructive start binding is admitted through the immutable AM grant set;
  stale refresh remains one-use and freshness-gated. Qualification mocks pass
  14/14, Program Runtime contract/binding tests pass, and the workflow was
  reconciled at the digest recorded above. No provider run or BAS enablement
  occurred.
- The delivery-role contract is now explicit in the canonical orchestration
  skill (revision 14) and effort-supervision docs: the standing Sol supervisor
  selects and accepts each ownership boundary; the economical Luna coordinator
  executes only the admitted boundary and returns a handoff; workers cannot
  choose, close, or replace the campaign boundary. The BAS team remains
  disabled and unqualified; this documentation repair changes no runtime
  admission.
- The lifecycle repair addressing the suspected pre-stop delay passes the
  focused race set (`internal/lifecycle`) including restart, operation-record,
  and engagement-routing owners. This is control-plane source evidence only;
  it does not replace the managed BAS outstanding-wait receipt.
- The E01 reset/session repair now has one `resetNavigation` owner for aborting
  pending waits, fencing attempts, clearing navigation identity and restoring
  the initial state; both the session-change effect and public reset use it.
  The conversation wrapper now likewise has one `resetConversationState` owner;
  session changes clear conversation admission without resetting navigation,
  while the public clear action uses the same owner with navigation reset. The
  focused record-mode navigation/conversation cohort passes 58/58, including
  observation-loss → terminal recovery → successor admission; `pnpm exec tsc
  --noEmit` and ESLint on the three changed owners pass. No behavior or
  qualification claim or net-complexity improvement is inferred from the
  extraction; the full 944-line navigation ownership surface remains under
  simplification review.
- After refreshing the installed control-plane binary, the retained J07 owner
  passed on the current BAS build `sha256:75e7b3f770eb2d66d03039e23510c0791ddc44f3a712db865c1636be374e51eb`:
  one external effect, resources 1→0, input stop 634.1 ms, restart
  preparation 613 ms, post-stop cleanup 17.2 ms, recovery 8.69 s, uncertain
  effect retained and retry denied. This is diagnostic owner evidence, not a
  five-case qualification receipt.
- The shared installed-CLI freshness path was repaired after the retained J07
  run exposed its cost: BAS's `api/**` freshness set is roughly 414 MiB, and
  the old control-plane entrypoint rehashed it before crossing the restart stop
  boundary. The cli-installer now persists the existing freshness manifest and
  the Vrooli manager evaluates its stat cache, with a one-time compatibility
  fallback for older installs. Focused `internal/cliinstall` and
  `packages/cli-core/cmd/cli-installer` tests pass; the refreshed BAS CLI now
  has a 221,738-byte freshness manifest and warm `vrooli scenario status`
  completes in about 30 ms instead of the multi-second pre-stop hash path.
- The current managed outstanding-wait J07 diagnostic was rerun after that
  repair on BAS build `sha256:0c62b8cf731ca1a68e82561d7b72114bc2eb67df4f7b3cefa81ab97899c46d46`:
  one external effect, resources 1→0, input stop 163.1 ms, restart
  preparation 150 ms, post-stop cleanup 10.6 ms, recovery 8.84 s, uncertain
  effect retained and retry denied. All diagnostic bands passed. The bounded
  line is retained at
  `.vrooli/runtime/rehabilitation-evidence/cancellation-restart-owner-20260928-manifest.jsonl`;
  this is one passing owner observation, not the five-case qualification
  receipt or E01 acceptance.
- The same J07 owner cohort was rerun against that unchanged build. It still
  observed one effect and released resources 1→0 with uncertainty retained and
  retry denied, but restart preparation was 1,676 ms, input stop 1,697 ms,
  cleanup 18 ms and recovery 9.45 s; only the input-stop band failed. The
  observation is diagnostic failure evidence, not a receipt. Same-build pass
  and fail results make preparation repeatability the next lifecycle question;
  do not widen the 1,000 ms band or assemble J07 from this run.
- A focused close-after-driver-loss repair is now deployed on refreshed BAS
  build `sha256:a240ce8614669da8e9b0b86f59d1b15d801ba135a499165cd3cbbff253fa6781`.
  The scenario is healthy after restart. Source tests prove that terminal or
  absent-session profile capture clears the stale binding and reports
  `profile_persisted=false`, while ordinary snapshot failures remain retryable;
  the managed normal create/close path passes with `profile_persisted=true`
  (receipt `.vrooli/runtime/rehabilitation-evidence/recording-close-current-candidate-20260928-r2.json`).
  A profile-backed managed reproduction then force-closed only its owned driver
  session before the public close request; the public API returned 200 with
  `profile_persisted=false`, cleared the binding, removed the synthetic profile,
  and left the driver healthy with zero sessions. Receipt:
  `.vrooli/runtime/rehabilitation-evidence/recording-close-driver-loss-current-candidate-20260928.json`.
  This closes the managed close-order gate; it does not qualify the broader E01.

## Next bounded actions

1. Preserve the passing J07 and managed close-owner evidence and complete the
   remaining E01 semantic exit: observation-loss recovery/new-request
   agreement, passive and export privacy evidence, and measurable net
   simplification. Do not widen timing bands or replace owner results with a
   broad suite. A future full qualification receipt still requires the other
   four cancellation owners and the controller's one-use admission.
2. Continue only with a bounded navigation lifecycle/event simplification if
   it removes a real duplicated transition or parser branch; focused recovery
   and admission tests must preserve behavior. Retain the passing synthetic
   session/frame and reuse probes as owner diagnostics, and show before/after
   ownership and complexity evidence rather than chasing line count.
3. Exercise observation loss followed by recovery and a new request. Prove UI
   state, command admission, and conversation history agree with no duplicate
   effect or orphaned message.
4. Retain the BAS-RF-017 redaction boundary. The deployed live API path and
   source storage/export readers now have bounded receipts; obtain
   recovered-status and managed passive/export/legacy-at-rest privacy evidence.
   The managed API and driver receipts are diagnostic only until a current
   candidate is rebuilt and reviewed.
5. Only after strong review accepts frozen content may the controller issue one
   qualification lease for worker → independent Sol review → qualification.

## Evidence and history

The previous active view is preserved as
`evidence/rehabilitation/refactor-progress-precompact-2026-09-28.md.gz`; its
compressed SHA-256 is recorded in the adjacent manifest. Earlier chronology is
in `refactor-progress-stopped-2026-09-27.md.gz` and the named salvage files.

The current runtime rehabilitation working set is 49 files, 5,658,726 bytes,
and 136,438 text lines, below the limits of 128 files, 16 MiB, and 250,000
lines. The current refresh added only the three bounded passive-fidelity owner
wrappers and their raw artifacts; no broad producer log was retained. Archive
superseded cohorts as one dated tarball with a manifest before any new broad
producer run. The owner retention sweep for recordings/captures does not own
this rehabilitation working set. Never delete a referenced artifact or use an
archive as resume input.

At every checkpoint record only changed, verified, remaining, and unverified
work. This mandate remains active until the operator stops or redirects it.
