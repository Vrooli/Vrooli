# Browser rehabilitation progress

This is the single active resume checkpoint, not an execution transcript. Read
[TESTING.md](TESTING.md), run the campaign guard, and search only the referenced
entries in [PROBLEMS.md](../PROBLEMS.md). Do not read the histories during
routine resume.

Full chronology through the stopped 2026-09-26 run is preserved at
[`evidence/rehabilitation/refactor-progress-history-2026-09-26-agent-run.md.gz`](evidence/rehabilitation/refactor-progress-history-2026-09-26-agent-run.md.gz),
SHA-256 `b18da33354046fb9a36205810e3d8b7ae2fe3f8fa4128e49e1905df9c45cf74b`.
Retrieve only when a present decision depends on it with `gzip -cd <path>`.

## Closed E58 — terminal outcome/remount identity

Candidate state: **frozen**

E58 outcome: navigation identity crosses callback boundary; focused 43/43,
record-mode 620/620; stale qualification.

## Closed E59 — callback teardown/recovery re-entry

Candidate state: **frozen**

E59 outcome: generation fencing suppresses stale starts; focused 45/45,
record-mode 622/622.

## Closed E60 — terminal-before-placeholder admission

Candidate state: **frozen**
E60 outcome: `onStarted` publishes the ID before observation; conversation owns
the placeholder. Focused 46/46, record-mode 623/623.

## Closed E61 — reconnect admission ownership

Candidate state: **frozen**
E61 outcome: generation-fenced admission rejects duplicate, late-terminal and
post-reset callbacks. Focused 49/49, record-mode 626/626; stale qualification.

## Closed E62 — synchronous send admission

Candidate state: **frozen**
E62 outcome: same-render send concurrency fenced. Focused 50/50,
record-mode 627/627; stale evidence.

## Closed candidate epoch E63 — successor admission identity

Candidate state: **frozen**
Qualification: provider `20260927-000455-3cb0bfa5` PASS; rehabilitation
`20260927-000507-395503b7` FAIL; setpoint 0/17.
E63 outcome: monotonic `onStarted` identity fences stale successors; 51/51,
628/628.

## Closed candidate epoch E64 — terminal successor admission

Candidate state: **frozen**
Qualification: provider PASS; rehabilitation FAIL; setpoint 0/17 readable.
E64 outcome: terminal successors use authoritative refs; 52/52, 629/629.

## Closed candidate epoch E65 — stale resume admission

Candidate state: **frozen**
Qualification: provider `20260927-001527-db08dc11` PASS; rehab
`20260927-001541-97841607` FAIL; setpoint `prog_90b7c7b6-2706-499e-bde2-cde61cfc49a7` 0/17.

E65 outcome: authoritative refs admit stale-callback resume. Focused 26/26,
combined 53/53, record-mode 630/630; qualification closed.

## Closed candidate epoch E66 — handoff acknowledgement fencing

Candidate state: **frozen**
Qualification: provider `20260927-002227-46ba6f06` PASS; rehabilitation
`20260927-002237-62c405e0` FAIL closed; setpoint `prog_10683e4d-3cf4-4f55-84fc-2c7298889c47` 0/17.
E66 outcome: successful abort/resume acknowledgements stay fenced until
terminal/resumed or recovery status; failures remain retryable. Focused 55/55,
record-mode 632/632; semantic checks pass.

## Active candidate epoch E67 — abort completion recovery

Candidate state: **frozen**
Qualification cycle: **unused**
E67 outcome: acknowledged aborts use bounded status recovery when completion is
missed; generation fencing preserves WebSocket precedence. Focused 29/29,
combined 56/56, record-mode 633/633; semantic checks pass.

## Candidate epoch E15 — status snapshot data isolation

Candidate state: **frozen**

Qualification cycle: provider `20260926-202044-85839445` passed with seven
provider warnings; rehabilitation `20260926-202054-06a9c986` failed closed on
seven evidence-completeness errors; setpoint
`prog_1a1e3dd9-0498-4623-85f5-55c61b1b9bb3` returned 0 readable / 17
unavailable against live build `sha256:8dc24bd…`. One managed restart completed
healthy. Consumed; do not rerun in E15.

E15 closure: the red nested-map/slice regression now proves recursive snapshot
isolation while preserving nil/scalars; focused tests, race checks and vet pass.

## Candidate epoch E14 — completion result persistence

Candidate state: **frozen**

Qualification cycle: provider `20260926-201737-d02576ca` passed with seven
provider warnings; rehabilitation `20260926-201747-dd60cf48` failed closed on
seven evidence-completeness errors; setpoint
`prog_e42f623e-4ad2-40b3-98a8-a56825d2694a` returned 0 readable / 17
unavailable against live build `sha256:daeb297…`. One managed restart completed
healthy. Consumed; do not rerun in E14.

E14 closure: terminal URL/error/summary persist through status; focused tests,
race, vet and proto breaking analysis pass. Repository proto lint remains
unverified due unrelated existing failures.

## Candidate epoch E13 — duplicate step callback idempotency

Candidate state: **frozen**

Qualification cycle: provider `20260926-201235-a3d4dc1f` passed with seven
provider warnings; rehabilitation `20260926-201244-58daf501` failed closed on
seven current-build evidence findings; setpoint
`prog_cb0b6af1-1571-42ab-8a51-df3150cf63ca` returned 0 readable / 17
unavailable. One managed restart completed healthy. Consumed; do not rerun in
E13.

E13 closure: duplicate active steps now produce one history entry, charge and
broadcast; distinct steps and `awaiting_human` remain supported.

## Candidate epoch E12 — late step callback reconciliation

Candidate state: **frozen**

Qualification cycle: provider `20260926-201039-1eda997e` passed with seven
provider warnings; rehabilitation `20260926-201048-9fb09db8` failed closed on
seven evidence-completeness errors; setpoint
`prog_2720e65b-16b6-464c-baa0-4b1716115a81` returned 0 readable / 17
unavailable because no current receipts matched the live build. One managed
restart completed healthy. Consumed; do not rerun in E12.

E12 closure: late terminal steps leave state, totals, credits and broadcasts
unchanged; `awaiting_human` remains resumable.

## Candidate epoch E11 — terminal completion idempotency

Candidate state: **frozen**

Qualification cycle: provider `20260926-200730-bd4baf9e` passed with seven
provider warnings; rehabilitation `20260926-200740-ac151d4a` failed closed on
seven evidence-completeness errors; setpoint
`prog_e006e100-8b7b-48e0-a479-60256bf7a48c` returned 0 readable / 17
unavailable because current receipts were absent or tied to a different build.
One managed restart completed healthy. Consumed; do not rerun in E11.

E11 closure: duplicate completion preserves the first result and broadcasts
once; focused vision, vet, race and diff checks passed.

## Candidate epoch E10 — recording mutation serialization

Candidate state: **frozen**

Qualification cycle: provider `20260926-200035-6a36363c` passed with seven
provider warnings; rehabilitation `20260926-200047-86c1e4c5` failed closed on
seven stale-current-build evidence findings; setpoint
`prog_fa8b70e2-f13a-47ee-8d19-db2aa7e53c36` returned 0 readable / 17
unavailable. One managed restart completed healthy. Consumed; do not rerun in
E10.

E10 closure: navigation shares the viewport mutation queue and retires frame
epochs first; focused navigation/input/frame/live-input checks passed.

## Candidate epoch E09 — same-page frame epoch retirement

Candidate state: **frozen**

Qualification cycle: provider `20260926-195712-a37b6f1d` passed with seven
provider warnings; rehabilitation `20260926-195723-837ef2b4` failed closed on
seven stale-current-build evidence findings; setpoint
`prog_4504ca2d-253f-4533-b881-0daccb7a8ea8` returned 0 readable / 17
unavailable. One managed restart completed healthy. Consumed; do not rerun in
E09.

E09 closure: same-URL navigation retires the frame slot before mutation;
focused navigation/frame, typecheck and lint passed.

## Candidate epoch E08 — viewport mutation admission fencing

Candidate state: **frozen**

Qualification cycle: provider `20260926-195319-6240e9f1` passed with seven
provider warnings; rehabilitation `20260926-195246-78da163f` failed closed on
seven stale-current-build evidence
findings; setpoint `prog_00329c5c-db68-4418-8e3c-cc8aa423c5c2` returned 0
readable / 17 unavailable. One managed restart completed healthy. Consumed;
do not rerun in E08.

E08 closure: viewport resize and frame refresh share the mutation queue; route,
live-input, frame, session, typecheck and lint checks passed.

## Candidate epoch E07 — deterministic session-manager validation

Candidate state: **frozen**

Qualification cycle: provider `20260926-194201-b9cf9150` passed;
rehabilitation `20260926-194348-0aab0316` failed closed on seven stale-current-build
evidence findings; setpoint `prog_19284d17-9d62-421c-9e4f-2aa82e2ec26e` returned
0 readable / 17 unavailable. Consumed; do not rerun in E07.

E07 closure: mocked idempotency fell 76.179 s to 10.103 s (15/15); readiness
close stayed 2/2, with typecheck, lint and diff checks passing.

## Candidate epoch E06 — released-session handoff fencing

Candidate state: **frozen**

Qualification cycle: provider `20260926-193459-b543f577` passed;
rehabilitation `20260926-193518-b45b6952` failed closed on
`EVIDENCE_COMPLETENESS_INVALID`; setpoint `prog_e87d7943-69ab-436e-ae68-303867d2fc85`
returned 0 readable / 17 unavailable. Consumed; do not rerun in E06.

E06 boundary and proof are recorded above; consumed qualification must not be
reset. E05 is historical; do not reuse its receipts.

## Candidate epoch E05 — cancellation interruption and stop-before-preparation

Candidate state: **frozen**

Qualification cycle: provider 20260926-182744-85397eb2 pass; rehab 20260926-182752-90c54d2b fail; setpoint unused

E05 boundary: cancellation stopped accepted input, preserved one uncertain
effect and recovered terminal state; focused owners passed and qualification
was consumed after the exact phase failed.

E04 remains a closed historical epoch below; its managed receipts are not
current evidence for E05.

### E04 closure record

E04's full scope and semantic gate remain in archived chronology; its managed
receipts are historical and invalidated by later source edits.

### Completed work units retained from the stopped run

- Prior work repaired session reuse, frame/cache ownership, input lifecycle,
  cancellation and callback delivery; detailed receipts remain in compressed
  history.

These statements are inherited evidence, not permission to skip inspection or
rerun qualification. Preserve the user's uncommitted changes; the agent never
commits.

### Compact inherited state

The campaign reset archived mixed evidence and verified termination of an
orphaned test child. Historical owner-boundary measurements remain in the
compressed history above; stale receipts are not reused. E06 and earlier
qualification cycles are consumed, with stale rehabilitation and unavailable
setpoint findings recorded in their epoch entries. Continue E11 with focused
checks, then freeze and qualify once.

### Retained historical state

Archive details, campaign cleanup, and unverified domains remain in the
compressed history; no stale evidence is admissible for E11.

In-epoch checkpoint 2026-09-26: changed the live-input and frame-cache
lifecycle owners and their callers/tests/probes; updated BAS-RF-020, BAS-RF-033
and this checkpoint. Verified the session route-boundary scan is empty, the
reuse/frame actual-module probes are 10/10 with no unavailable cases, driver
typecheck passes, and the combined focused lifecycle/frame/session suites pass
336/336 and exit without an owned runner. Source measurements are explicit:
recording-input is 373→213 route lines plus its owner; recording-frames is
188→154 route lines plus its 35-line owner. The touched-owner lint is clean,
and the directly affected frame/record route suites pass 133/133. Guard
`--stage resume` passes after the checkpoint rewrite. Semantic exit gate met
for this ownership boundary: finalization/fault checks pass; session
reset/teardown have zero route-layer imports; the dead
`cleanupSessionRecording` caller surface is removed; touched tests are net
seven lines smaller; and route implementations are 194 lines smaller before
the explicitly measured 252 lines of two session owners. The product fixes
(input ordering/lease cleanup and reset/close frame-cache retirement) are
supported by focused expected-behavior checks. Qualification-only work is
closed with current-build owner receipts: evidence-completeness, resource
budget, cancellation/recovery, motion, local/remote interactive feedback,
profile durability, and passive fidelity all passed. The invalidated motion
run overlapped cancellation's managed restart and was excluded; the isolated
rerun passed. Test Genie passed L1 Verified. The required setpoint read was
fresh but remains telemetry-unavailable rather than product-qualified.
Unverified: native/device/desktop behavior and domain-wide debt outside this
boundary.

E06 checkpoint 2026-09-26: the red handoff test failed before repair. The
manager now joins admitted input, retires page input identity, clears the
session frame cache and resets frame selection before transferring a released
lease. Browser state remains retained. Idempotency 15/15, frame-streaming
34/34, typecheck and touched-owner lint pass; managed restart is healthy on
`sha256:a5c2570964e3d63ccedc7b3d80a96839c353bb9c360ba6e5138a503045370d97`.
The exact E06 receipt was not publishable because evidence completeness was stale.

### Reopened investigation — retained-page input ownership

The frozen closure exposed a product defect in the same lifecycle boundary:
`resetPageInputState` releases pointer modifiers but leaves the retained page's
input queue, sequence counter and idempotency receipts alive. Hypothesis: after
reset, a new lease reusing the retained page can replay an old `input_id` and
receive the previous receipt without applying its new input. The discriminating
regression will admit one input, reset the page owner, reuse the same input ID
with a different effect, and require one fresh browser effect/sequence. A
separate check will prove an admitted pre-reset queue settles before reset and
cannot publish into the new lease. This reopens E04 rather than creating a new
epoch; qualification evidence is invalidated only after a source edit.

Implementation checkpoint 2026-09-26: the retained-page defect reproduced as
predicted, then `resetPageInputState` was made self-contained: it joins any
admitted queue, releases modifiers, and retires the page-keyed queue and
idempotency maps before returning. The direct owner regression passes 2/2; the
adjacent frame/input/recording/session suites pass 338/338, actual-module
probes pass 10/10, and typecheck plus touched-owner ESLint pass. This is a
product repair, not a qualification refresh; prior frozen receipts are
invalid after this source edit. Remaining: inspect analogous retained-page
state, complete the semantic gate, then freeze once; do not reset the closed
qualification identity. Unverified: managed/native reset behavior and all
post-repair owner receipts.

Semantic exit gate reopened and met for the retained-page repair: the failing
expected-behavior regression now passes; no second page-keyed input owner or
route-layer session import was found; the adjacent 338-test boundary, probes,
contract preparation, docs tests, typecheck, lint and diff checks pass. The
candidate is frozen again. Qualification cycle remains closed once by policy;
the prior managed receipts are intentionally treated as stale after this
source edit, and no second exact provider phase or setpoint qualification is
admitted in E04.

## Epoch summary — prior stable owner-boundary candidate — 2026-09-26

The last stable candidate before later source edits reached 8/17 readable rows:
seven owner-backed capabilities plus capture. Interactive transport continuity,
owner receipt identity and several lifecycle defects were materially repaired.
That score is historical comparison evidence only; later source edits
invalidated candidate-bound receipts without proving product regressions.

## Epoch summary — campaign-control reset — 2026-09-26

The stopped run delivered useful code but violated epoch, active-packet,
evidence-retention and process-hygiene rules. Its narrative and mixed runtime
cohorts were archived recoverably. Resume under the executable guard and this
single large epoch; do not reconstruct the 42 micro-epochs in active state.
