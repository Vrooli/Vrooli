# Browser rehabilitation progress

This file owns the current checkpoint and recent append-only execution history;
older immutable records are preserved in its linked archive. Follow
[TESTING.md](TESTING.md); use
[PROBLEMS.md](../PROBLEMS.md) as the only defect register. There is no active plan,
phase progression or external execution-log dependency. Maintain this small
current-state section, then append dated records without erasing prior evidence.

## Current checkpoint — targeted owner refresh and freshness response — 2026-09-26 UTC

The healthy, fresh managed BAS candidate is `sha256:7edf0d16…`. The latest
governed read `prog_98e5fa50-6016-4d5e-b9ea-2cce7279f21e` reports **4/17
in-band, 13 unavailable, 0 out of band**, `product_qualified=false`; lifecycle
freshness is true with three checks. The in-band rows are
capture (100 samples, p95 477 ms against a 2,000 ms budget), evidence
completeness (L1 clean), profile durability (L1 clean), and cancellation/recovery
(L1 clean). The exact provider phase still reports three unavailable owner
capabilities: passive fidelity, resource budget and motion. The other ten rows
remain pending telemetry. No full Test Genie suite ran.

The resource-budget owner was attempted once as the next bounded receipt. It
exited before sampling because the managed driver reported nine active sessions
and zero recordings. The owner requires zero sessions throughout; no session
was closed. Retry only after the shared driver is naturally idle.

The required setpoint initially timed out at 60 seconds on a stale candidate.
After a managed rebuild and warm lifecycle cache, one freshness call still took
66.7 seconds, but setpoint reads completed in 8.9–15.7 seconds. The persistent
score-path gate was the old capture workload identity: rehabilitation owner
standings are consumed only when the 100-sample capture measurement matches the
current build and the exact phase runs after its capture timestamp. Refreshing
that one workload (p95 477 ms) restored two rows immediately. Targeted evidence
completeness and profile-durability owners then raised the current score to 3;
the cancellation owner and phase raised it to 4.

BAS-RF-145 also now propagates request cancellation from the freshness RPC
through the application service and lifecycle resolver. A focused regression
identified the remaining response failure: root API omitted `WriteTimeout` and
used api-core's 30 s default. The setpoint program's 110 s wall budget correctly
allowed the 90 s bridge, but restarting without rebuilding reused an old API
binary. After `make build` and a managed API restart, the same governed read
completed in 6.9 s and freshness returned successfully. The root API now uses
a 2 min write timeout; the shared default is unchanged. Focused timeout and
cancellation regressions pass. A separate direct lifecycle CLI request can
still take about 66 s; this response-delivery fix does not claim that latency is
resolved.

Scope extension for BAS-RF-145, before edit: the latest required read
`prog_d3df6c98-3c68-4c4a-a6f8-efaafdc13ee2` again exhausted its 60 s wall
budget; the root API access log shows the same `GetScenarioFreshness` request
returned after 69.965 s. The BAS setpoint contract declares `budget.wall_ms=60000`,
while its owning Program Runtime has `BridgeCall=90s`, `KernelInvoke=100s` and
`SyncSubmit=120s`. The call therefore outlives its parent program budget. The
bounded repair surface is only BAS's `.vrooli/program-runtime/setpoint-read.json`
and its focused contract tests. Align this read-only program's wall budget to
110 s, below synchronous submission and above kernel invocation; do not change
the shared Program Runtime ladder. Verify the fixture contract and one live
setpoint read after the edit. This is a budget ownership correction, not proof
that 70 s freshness latency is acceptable or resolved.

Further W275 scope extension, before edit: the live Program Runtime invocation
ledger records the freshness failure as `EOF` at 72.098 s; root API access
middleware logs status 200 after 71.955 s. `cmd/vrooli-api/main.go` leaves
`api-core/server.Config.WriteTimeout` unset, whose default is 30 s. The server
therefore closes the response writer before this long handler finishes. Extend
the repair to root API server configuration and a focused configuration
regression. Use a 2-minute write timeout so the response outlives the 90 s
Program Runtime bridge limit; do not change the shared api-core default. Retain
the 110 s BAS program budget from the previous extension, below the 120 s
synchronous submission ceiling.

W274 further separates capture workflow construction from optional postlude
nodes and profile overrides. `buildAdhocRequest` drops from cyclomatic
complexity 19 to 8; the focused capture handler package passes in 0.310 s and
no touched capture function exceeds 14. These are cohesion/max-hotspot
measurements, not a claim that domain-wide complexity fell. The API change has
not been deployed, so no refreshed build-bound receipt or score applies to it.
The scoped preparation tests initially exposed an outdated harness that omitted
the now-required freshness binding. Its default fixture now models a fresh
candidate, and a separate regression asserts that missing freshness remains
partial and withholds all 17 rows. The test failed before this fixture repair;
all 15 preparation tests pass in 0.088 s afterward.

BAS-FB-036's permanent identity policy remains: scenario `docs/` is excluded by
default, exact runtime-served docs use `build_identity.runtime_docs`, and
`.vrooli/service.json` remains identity-bearing. GCT safe-padding remains
separate and has not been attributed to BAS. The progress history remains
compacted into its linked archive. Next, refresh one directly useful missing
owner at a time; the remaining passive-fidelity, resource-budget and motion
receipts must be current before claiming those outcomes. Avoid unchanged broad
suites and receipts.

W273 changed the UI frame delivery implementation and its owner test. The
managed restart produced fresh candidate `sha256:56989be5…`, but the required
setpoint now reports **0/17 in-band, 17 unavailable, 0 out of band** because
all previously qualified receipts were tied to the prior candidate. This is a
fresh source-valid reading, not a product regression; the candidate is healthy
and fresh. Evidence-completeness has been refreshed on this candidate, but no
provider phase was run because the remaining receipts are stale. The driver
currently has nine active sessions owned by a React Component Library workflow;
I left them untouched and deferred browser owners to avoid invalid load. Recheck
the session list before running the motion owner.

The earlier checkpoint and detailed W228–W266 outcomes stay in the linked
archive; W267 onward remains in this active log.

## Archived prior work records

Detailed W228–W258 outcomes and BAS-WORK records are preserved verbatim in the [dated rehabilitation history archive](evidence/rehabilitation/refactor-progress-history-2026-09-25.md). W240–W266 were moved intact during W262/W267 compaction; only the current W267 checkpoint remains active. Archive SHA-256: `006e574e964aa8ae1921113978d46fc008c240bcdde63634e6be996e208422d4`.

### W267 scope — refresh current-build evidence and report score truthfully

The managed BAS API and UI artifacts drifted from source while runtime status
still reported a healthy server. The old 7/17 score must not be treated as a
current-source measurement. Rebuild/restart through the lifecycle, verify
freshness, then use only the capture workload and named evidence-completeness
and profile-durability owners needed to recover directly measured rows. Run the
exact `rehabilitation-evidence` phase once for refreshed owner receipts and the
governed setpoint once afterward. Preserve stale rows as unavailable. Record a
BAS-RF issue for the separate score-reader artifact-freshness gap before
extending the shared control-plane binding surface.

### W267 outcome — fresh candidate restores three measured rows

Lifecycle freshness was stale before restart: the API binary had drifted after
`api/handlers/capture/service.go` changed and the UI bundle after shared proto
generation. Managed restart rebuilt the stale artifacts; subsequent freshness
reports `stale:false`, with current build `9bd2cd24…`. The capture workload is
within its 2,000 ms budget (100 samples, 467 ms p95; receipt operation
`1f827668663a57fcc909e6faec1fb3fd`). Evidence-completeness retained all four
named Go tests and passed; profile durability passed five seed checks and two
post-restart identity checks, with both profiles deleted after verification.

The exact `rehabilitation-evidence` runs failed only on other stale current-build
receipts: first five findings before profile refresh, then four findings for
cancellation, passive fidelity, resource budget and motion. The latter run
`20260926-003031-e777a0a8` verified evidence-completeness and profile-durability
L1/clean. Fresh governed setpoint `prog_c84385fb-22a1-46b1-8e2a-bc21f5f2f04d`
reports **3/17 in-band, 14 unavailable, 0 out of band**, `product_qualified=false`.
No broad suite ran. `make restart` took several minutes because lifecycle safely
rebuilt two stale shared dependencies without restarting their live consumers;
optional Claude credentials remain unavailable and are unrelated to this
measurement.

Next: isolate the slow Program Runtime evidence read before refreshing more
owners. The remote interactive-feedback sensor/cohorts, four stale
rehabilitation owners, and remaining telemetry rows remain open.

### W268 outcome — lifecycle freshness guard and focused receipt refresh

Added `GetScenarioFreshness` over the existing lifecycle service and registered
`vrooli/scenario/freshness`. BAS withholds all 17 rows before capture/Test Genie
reads when freshness is stale, missing or unknown; a live stale candidate
confirmed the guard. Proto3 Connect omits false `stale` fields, so the reader
accepts omission only with successful status and non-empty checks. Five focused
BAS tests, root API mapping tests and binding contract tests pass. After managed
restart, direct freshness reports all three BAS artifacts current; capture
passed at 439 ms p95, and the four named evidence-completeness tests passed on
that build. One fresh governed read exceeded Program Runtime's 60-second limit
and emitted no score. No broad suite or rehabilitation phase ran.

### W269 scope — isolate lifecycle freshness latency

The isolated Program Runtime freshness binding exceeded 30 seconds; root API
logs show 47.993–75.936 second requests, versus 10.08 seconds for the direct
lifecycle CLI. Binding condition evidence places freshness at 8.512 seconds
p50 / 12.823 seconds p95 with 25% failures; Test Genie list p95 is 170 ms.
Hypothesis: the Go-closure resolver failure is retried before static fallback.
The bounded discriminator is a single focused lifecycle test asserting one
Go-list attempt before fallback. This extends BAS-RF-145 only into the shared
lifecycle freshness input path; stale verdict semantics remain unchanged.

### W269 outcome — remove duplicate slow fallback

The discriminator failed before the fix: one builder freshness request made
two Go-list calls after the first failed. The builder now attempts Go-list once
and falls directly to static inputs; the standalone binary helper retains its
single-attempt behavior. Focused lifecycle tests pass. After the managed root
API rebuild, direct freshness completed in 8.29 s and an isolated Program
Runtime binding in 11.70 s. The required setpoint then completed in about 10 s
instead of timing out and returned a fresh 1/17 baseline.

### W270 outcome — refresh three targeted owner rows

The exact evidence phase first identified profile durability as its next move.
Its managed owner passed five seed checks, including alpha/beta isolation and a
1,342 ms checkpoint; after a managed BAS restart, both identities survived and
both synthetic profiles were deleted. Assembly bound the receipt to the live
build. The next exact phase verified profile durability and evidence
completeness, then exposed cancellation/recovery as the next move. The focused
J07 runner passed four Go/Playwright owners plus managed API restart recovery:
one effect per case, all resources cleaned, uncertainty retained, no retry
admitted, and restart recovery in 4.73 s. The latest exact phase verifies all
four current rows and identifies passive fidelity as next. The three passive
owners then passed: the managed 10,000-action journal cohort (48.5 s), the
recording process-death/same-ID test, and all three selected browser-semantics
cases. Assembly verified all three receipts on the live build. The exact phase
now verifies five rows and identifies resource budget next. Setpoint operation
`prog_3053dba6-0579-4d1f-85a0-3449eaf1f972` reports **5/17 in-band, 12
unavailable, 0 out of band**. The resource owner was not started because its
idle precondition is false: the live session list reports 9 active sessions
(10 listed), all sharing one workflow ID. No caller session was closed. A
focused test-helper audit found the existing mock, HTTP, fetch, config and
instruction helpers already centralized; the live Connect client appears only
once, so no abstraction was added. One redundant rerun of the passing lifecycle
regression took 74 s under concurrent Chromium load; avoid repeating it without
another code change. No full suite ran.

### W271 scope — isolate managed motion frame loss

The current 30 FPS / five-minute owner failed on build `sha256:8c0a7917…` after
receiving and decoding 9,000 frames but painting 8,994. Fixture cadence was
30.0056 FPS, p95 decode 3.5 ms and p95 frame age 23 ms; the phase therefore
points to the viewer paint boundary rather than fixture generation or decoder
throughput. BAS-RF-146 records the measured defect and falsifiable hypothesis:
one-pending-frame replacement may coalesce paints when requestAnimationFrame
cadence aliases the 30 FPS source. Next, compare bounded 30 FPS and elevated
source-rate smoke windows on the same current build, then add a deterministic
regression for any reproduced scheduling defect. Do not weaken the 30 FPS band.
The slow-reader half of the full owner remains unverified because the baseline
assertion failed first. The post-resource setpoint operation
`prog_04389d1f-401a-4ee2-a269-dd190c123759` timed out at 60.006 s with no score;
its terminal record is `kernel_runtime`, and prepare-operation confirms the
program digest and current binding set. Do not retry unchanged until diagnosing
its variable slow binding. The latest completed score remains 5/17; the exact
phase now verifies six owner capabilities including resource budget.

### W271 outcome — short motion smokes did not reproduce the full deficit

On the same build, the 15-second 30 FPS smoke received, decoded and painted
450/450 frames. The 60 FPS diagnostic painted 448/450 and is not qualifying
evidence. These short runs did not reproduce the five-minute deficit, so the
requestAnimationFrame aliasing hypothesis remains unproven. Keep the 30 FPS
band unchanged and test the scheduling boundary deterministically before
repeating the five-minute owner.

### W272 outcome — narrow closure-cache work restores governed read

The repeated slow freshness path was narrowed to `closureCacheKey`: before it
could read a cached closure, it recursively fingerprinted every local `replace`
tree, including the repository root. Added a regression that changes Go source
in an unrelated scenario and requires a cache hit; it failed before the repair
with two Go-list calls. The cache now fingerprints only the Go files in package
directories and module files present in the cached import closure. Existing
checks still require misses when `go.mod` or a resolved package changes.

The focused lifecycle set (durable-cache hit, module-change miss, package-source
miss, unrelated-source hit and single failed Go-list fallback) passes in 0.16 s;
`refactor_contract.py` passes. After managed root API rebuild, the required
setpoint operation `prog_e2116eb9-b0c8-4f01-9a58-8be06802bb77` completed in
11.435 s, reports a fresh candidate and scores **6/17 in-band, 11 unavailable,
0 out of band**. The prior W271 timeout is closed as a current blocker; BAS-RF-145
remains open for the readiness row's `pending_telemetry` sensor gap. The exact
motion row remains unavailable after the failed owner phase. No full Test Genie
suite or broad evidence refresh ran. Task-record `bb269c32-30eb-4d9d-b0ca-987cba2ff856`
and work-record `f423b153-12bd-45ac-a984-9ce29752d80b` preserve the operation
and repair evidence.

### W273 scope — preserve frames across delayed RAF paints

BAS-RF-146's five-minute owner decoded all 9,000 stream frames but painted only
8,994. Matched short smokes did not reproduce this. A direct regression now
reproduces the viewer boundary: decode two sequential frames before one delayed
RAF callback; the old one-slot `pendingPaint` closed frame 1 and drew frame 2
first. The implementation now keeps a two-frame paint queue bounded to 16 MiB
of decoded pixels, drops and closes the oldest frame on overflow, and schedules
one RAF at a time. The existing decoder remains one-active/newest-pending.

The UI owner test now covers ordered recovery after a delayed paint callback,
count-bounded slow paints, decoded-pixel byte-budget eviction and bitmap
cleanup. It also replaces unchecked WebSocket/decode array access with checked
fixture helpers and captures the decoder ref for effect cleanup. This removed
45 non-null warnings from the focused ESLint run and the cleanup warning; no
unrelated test helpers were added. The changed production UI source invalidates
the previous candidate-bound score, so a managed rebuild and fresh motion owner
are required before another exact phase or governed read. Do not reuse receipts
from `sha256:8c0a7917…` for the new candidate.

### W273 outcome — deterministic paint loss repaired; current receipts reset

The new regression failed before the implementation and the focused viewer
suite now passes 34/34. A two-frame backlog preserves a decoded 30 FPS pair
across a delayed RAF callback; overflow retains the newest two and closes each
discarded bitmap; a 16 MiB decoded-pixel cap evicts an older large raster.
The focused `useFrameStream.test.ts` file, targeted ESLint and the UI TypeScript
check pass. Replacing unchecked array assertions with checked fixture helpers
removed the test file's non-null warnings; capturing the decoder object also
cleared its cleanup warning.

`vrooli scenario restart browser-automation-studio` completed healthy after
rebuilding stale shared dependencies without restarting their other consumers.
Lifecycle freshness reports all three BAS artifacts current on
`sha256:56989be5…`. The required setpoint
`prog_c04e806c-4d96-47a6-9063-0b278e00a8c1` completed in 10.768 s and reports
0/17 in-band, 17 unavailable: previous-build evidence is correctly rejected.
The current-candidate evidence-completeness owner passed all four named tests
and wrote receipt `evidence-completeness-2026-09-26T02-57-36-707Z-4e94d052.json`;
the exact Test Genie phase waits until the remaining current-build receipts are
refreshed. At that read, nine foreign driver sessions prevented a valid motion
measurement; none were closed. The RCL workflow later drained naturally, and a
fresh pool check showed zero sessions. The current-candidate motion owner then
passed: 9,000/9,000 frames rendered over 300,003 ms at 29.9997 FPS, p95 age
25 ms, max age 27 ms; the 18-second slow-reader cohort rendered 210/540 frames,
kept one active decode, p95 age 142 ms/max343 ms, and max API queue 9,440,256 B
under the 12,587,008 B budget. Receipt:
`motion-receipt-2026-09-26T03-01-00.145Z-9b1878b2-8946-4332-bb15-5791cd30d760.json`.
The current-candidate owner refreshes subsequently passed profile durability,
cancellation recovery, passive fidelity, resource budget, motion, capture and
evidence completeness. The exact `rehabilitation-evidence` Test Genie phase
passed; its six governed capability rows are L1 clean. The required score read
`prog_6ef42f93-6903-45f8-9883-71b8e4f98786` then exceeded Program Runtime's
60-second ceiling while awaiting lifecycle freshness, so its score is unknown.
One targeted `vrooli scenario freshness browser-automation-studio --json` read
took 65.470 s. In contrast, a focused real-runner profile completed the same
freshness report in 0.773 s; artifact construction/evaluation phases took at
most 2.15 s and 48 ms. Go-list took 0.738 s, closure hashing 26 ms, and
manifest-file stats 13 ms in isolated measurements. These reject the BAS
closure cache and lifecycle artifact checks as the long-delay cause; the
managed command/API path or its runtime conditions remain unlocalized. Do not
repeat the same governed read until that path changes or a targeted measurement
identifies a fix. No broad suite ran and no synthetic owner receipt was promoted.

### W275 outcome — targeted score path restored; four current rows qualified

The managed root API now carries request cancellation through the freshness RPC,
scenario service and lifecycle Go-list/artifact checks. Focused regressions pass
for canceled Go-list resolution, an already-canceled lifecycle report and API
handler cancellation. Root API restart completed through `make develop
DEVELOP_ARGS="--restart-api --resources none --scenarios none --onboarding
none"`. A direct live freshness read still took 66.7 s; the governed setpoint
calls completed in 8.9–15.7 s after cache warmup. This narrows cancellation
behavior but does not claim the direct CLI latency is resolved.

The fresh managed BAS candidate is `sha256:7edf0d16…`. The 100-sample capture
workload passed at 477 ms p95 / 689 ms wall p95 against a 2,000 ms budget.
Evidence-completeness passed four named tests and its exact provider capability
is L1 clean. Profile durability passed five seed checks and two managed-restart
checks; both synthetic profiles were deleted. Cancellation/recovery passed all
five observations: one external effect, resources cleaned from 1 to 0, no retry
admitted, and recovery after restart. Its restart observation recorded 64.1 s
total, 57.7 s until accepted input stopped, and 143 ms cleanup; retain this as a
latency signal.

The latest setpoint `prog_e04c577b-7f98-4ff0-96ca-0245c5e89955` reports **4/17
in-band, 13 unavailable, 0 out of band**, with `product_qualified=false`. The
exact `rehabilitation-evidence` phase reports evidence completeness, profile
durability and cancellation/recovery L1 clean; motion, passive fidelity and
resource budget remain unavailable, and ten other outcomes remain pending
telemetry. It fails only for those three missing owner receipts. No full suite
ran. The broad lifecycle package check took 48.9 s and failed unrelated
portability/shared-package assertions; its focused cancellation tests pass in
0.13 s (lifecycle) and 0.01 s (API). The preparation contract is valid (17
outcomes, 24 journeys); its 14 focused Python tests pass, and the current
inventory snapshot completed. Next, target one of the three remaining owner
receipts without repeating unchanged score or broad-suite work.

### W276 outcome — root API delivers the freshness response

The 60 s BAS setpoint ceiling first caused a parent timeout while the nested
freshness request continued. Raising only that declared read-only program to
110 s exposed a second issue: Program Runtime recorded EOF at 72.1 s because
`cmd/vrooli-api` used api-core's default 30 s response write timeout. A focused
API regression now guards the root server timeout above the 90 s bridge limit;
the root API sets 2 min while the shared api-core default remains unchanged.
`make develop --restart-api` alone reused a pre-change binary, so the managed
`make build` was required before restart. After that, the required setpoint
`prog_98e5fa50-6016-4d5e-b9ea-2cce7279f21e` completed in 6.9 s: freshness is
true on the unchanged `sha256:7edf0d16…` candidate and the score remains 4/17,
with 13 unavailable and zero out of band. The focused root API timeout test
passes; the BAS program-runtime workflow module passes 51/51; contract
validation reports 17 outcomes, 24 journeys and no errors; inventory and
targeted whitespace checks pass. No broad suite or full evidence phase ran.

### W277 outcome — resource owner honors shared-session isolation

The targeted `node cmd/resource-budget-cohort/qualification.mjs` check exited
in 69 ms at its initial precondition because the managed driver had nine active
sessions and no active recordings. It collected no samples and changed no
session. The owner correctly refuses to close or measure around another
caller's browser work; retry it only after the driver is idle. This did not
change the valid current 4/17 score. No broad tests or evidence phases ran.

### BAS-FB-036 scope extension — declare bundled runtime documentation

Before editing, source inspection found that `ui/src/domains/docs/content/nodeDocumentation.ts`
imports 28 `docs/nodes/*.md` files with Vite's `?raw` loader, embedding their
contents in the served UI. `.vrooli/service.json` currently has no
`build_identity.runtime_docs`, despite lifecycle support for exact declared
runtime-doc paths. This contradicts the earlier audit note that no BAS runtime
docs needed declaration. Extend the fix to BAS `.vrooli/service.json` and add a
focused preparation regression that derives imported Markdown paths and
requires an exact manifest match, existing files and no overlap with
`exclude_paths`. Keep the shared lifecycle implementation unchanged. Verify
the failing-before/fixed-after test and targeted lifecycle policy test. The
manifest is itself build-identity input, so the resulting candidate must be
rebuilt before existing owner receipts or product evidence can be reused. The
managed driver currently has ten active sessions; do not restart BAS or close
them to force that verification.
