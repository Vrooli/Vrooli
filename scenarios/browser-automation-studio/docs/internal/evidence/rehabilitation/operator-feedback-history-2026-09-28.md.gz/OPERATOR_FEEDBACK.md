# Browser rehabilitation operator feedback

This active ledger contains unresolved material directives and the latest
execution-policy changes. The verbatim BAS-FB-001–042 history, including status
questions and prior responses, is preserved in
[`evidence/rehabilitation/operator-feedback-history-2026-09-26.md.gz`](evidence/rehabilitation/operator-feedback-history-2026-09-26.md.gz)
(SHA-256 `ae92b5350d625ee6ae3a0b576ad3354a7bfa1e87ec9b3435ea5298d3ea97e0db`).
Retrieve with `gzip -cd <path>`; do not read the archive during routine resume.

New material feedback is quoted verbatim once before acting. Semantic repeats
link the original entry. Status questions, acknowledgements and bare
continuations belong in the current checkpoint, not this durable ledger.

## Open directives

### BAS-FB-054 — GPT-6 catalog correction

> Earlier you said this:
> “The live runner catalog exposed a real configuration defect: it now offers `gpt-5.6-luna` and `gpt-5.6-sol`, while the policy still names unavailable `gpt-6-luna`/`gpt-6-sol`. I’m correcting the resource-owned policy to the measured catalog, preserving Luna-medium delivery and infrequent Sol-only review, then I’ll reload/verify Agent Manager’s effective profiles. This is a concrete integration gate, not a speculative model change.”
>
> This is a mistake that has been made several times. But the fact is that those gpt-6 versions DO in fact exist

Status: accepted correction. The owner-validated Codex 0.156.1 catalog reports
`gpt-6-luna` and `gpt-6-sol`, and the resource-owned policy maps delivery to Luna
and independent supervision to Sol. The older managed `debug models` listing
and compatibility cache may omit them, but neither is proof that either GPT-6
model is unavailable. No policy downgrade or active-run rewrite is authorized
by this feedback.

### BAS-FB-053 — Plan Manager is optional and phase-specific

> Yeah we definitely shouldn't require plan manager for everything. It only applies for specific cases and never for this large effort orchestration or harness goals. It's basically useful for shorter work that has clear phases

Status: accepted as an architecture clarification. Plan Manager is an optional
plan-shaped owner for shorter work with a clear phase order. Large-effort
orchestration, harness goals and continuous owner-backed scenario improvement
must use their existing team, Agent Manager and scenario-owned contract without
creating a plan unless the operator explicitly selects a plan-backed shape.

### BAS-FB-052 — supervisor review should use token accounting, not a wall-clock cap

> Earlier you said the review is capped at 120 seconds. What do you mean by that? That's not only too short, but unenforceable. I think it'd be better to let it review as needed, but keep the spawn limit and have it so we track the tokens spent by each supervisor and give it additional push when it's been taking too long to try to optimize itself or something like that

Status: accepted as a policy correction. The 120-second figure was a mistaken
wall-clock allowance, not a reliable enforcement mechanism. Supervisor runs keep
the no-overlap/spawn limit and finite owner-admitted token/charge budgets, with
actual usage recorded when available. Elapsed time is a signal for one targeted
pace-and-simplification directive, never an automatic kill or renewal. Runtime
adoption and token accounting remain unverified until an owner receipt proves
them.

### BAS-FB-051 — smaller setup model; financial distress

> Gotcha. I'm going to switch you to a smaller model as well, since I can't afford this. Really your inefficiency is causing me financial distress. This is honestly ridiculous. You need to lock in and get this done

Status: open. Preserve a bounded, actionable handoff for the model switch. Do not
launch more premium work to prepare it. Prioritize the remaining integration
gates, reuse accepted evidence and stop reopening settled implementation choices.
Do not claim completion or efficient operation without the end-to-end pilot.

### BAS-FB-050 — another 15% of weekly usage; supervisor costs at least 10×

> Status update? You've used another 15% of my weekly usage in the past few hours. You need to hurry up and get this done efficiently, and make sure the supervisor and orchestrators are also really efficient. That includes limiting how much the supervisor runs, since it's at least 10x more expensive to run than the orchestrator

Status: open. These are operator-reported usage/cost figures, not measured billing.
Repeated small premium reviews violated the efficiency intent. Batch review of a
coherent candidate, retain findings across repairs and prohibit unchanged-status
wakes. The delivery amendment now specifies bounded cadence; runtime enforcement
and a successful pilot are still unverified. No new premium run for this update.

### BAS-FB-049 — targeted pace intervention

> You have been running a lomg time. you seem to be making more progress and more efficiently since last time I told you to hurry it up, but please still hurry up. Honestly it could be the case that if a superviror or orchestrator notices friction in a subagent or other agent it's supervising, that sending that agent something along the lines of (paraphrasing here) "you're taking too long and spending too much time on validation/testing/etc. and not making much actual progress. Please hurry it up" could help remedy things

Status: accepted as an intervention hypothesis, not proven causal benefit.
Use the existing owner message/directive route for one specific pace correction:
name the observed repetition, reusable evidence, next accepted deliverable and
required check. Preserve quality gates, simplification, authority and budget.
Assess the next changed work/result; do not repeatedly nudge without new evidence
or treat a legitimate producer wait as wasted work. This applies to setup too.

### BAS-FB-048 — Luna 6 primary; Luna 5.6 fallback authorized

> It shows the correct model when I open it. But the 5.6 as a fallback is fine /home/matthalloran8/.vrooli/cache/vrooli/web-console/uploads/3df7e216-b0b0-4a41-922d-1a5ef784f4b1/IMG_1253.jpeg. It could be that you already fixed this and this question is stale

The screenshot shows GPT-6-Luna medium in Codex 0.156.1. The earlier model-choice
question is stale: protected Luna 6 and Sol 6 runs have now started through AM.
Luna 6/medium remains primary; Luna 5.6/medium on the same subscription is the
only newly authorized delivery fallback. This does not authorize premium or
metered fallback, changing active run snapshots, or activating the BAS campaign.
Status: applied to the existing resource policy and regression test (passing).
Live AM resolution selects Luna 6 and retains only Luna 5.6 as its fallback.
Work record `d66dd76e-e57b-4d34-8bdf-2f8b95fb9c74` and the integration checkpoint
own adoption evidence; no new model probe or active-run change was needed.

### BAS-FB-047 — setup-agent cost failure; efficiency and simplification are acceptance requirements

> Please make notes/logs that you have been running for about 8 hours and have blown through a quarter of my weekly usage. This is partly because you're Astra, which is an expensive codex model. So it's really important that the agents doing the main work are gpt-6-luna-medium, the supervisor is smarter and runs much less frequently, and the process as a whole is efficient and the agents don't have to spend a bunch of time repeating work, validation, or investigations (likely all still not achieved despite you working for so long already). Make sure you're focusing on efficiency as well as the agents actually progressing properly. And remember that the purpose of the supervisor is to make sure the orchestrators are efficient and progressing, the purpose of *you* is to make sure this process as a whole is set up properly and working correctly, and that you yourself are not progressing quickly or efficiently. Also keep in mind that agents always tend to do more work than needed and struggle to *simplify*. That means you too but especially the lower powered agents need more emphasis and push to make sure things are working clean and maintainably. Without the push for simplification, they will always add more and more code and that quickly becomes unsustainable and breaks.
>
> And I will emphasize again. You have blown through a QUARTER of my weekly usage in 8 hours and have failed to complete the goal. That is unacceptable, and means you are failing at the efficiency you are trying to set up for the supervisors and orchestrators

Status: open; this applies to the setup agent as well as the eventual campaign.
The duration and weekly-usage fraction are operator-reported; the billing fraction
was not independently measured. The setup effort has not delivered the required
end-to-end pilot. Source tests are not evidence of efficient unattended delivery.
The [delivery amendment](../../../../docs/agent-system/EFFORT_SUPERVISION.md#delivery-campaign-amendment--2026-09-26)
owns the corrected role, model, efficiency and simplification requirements. The
[current integration checkpoint](../../../../docs/agent-system/effort-supervision-validation.md#current-integration-checkpoint--2026-09-27)
must expose remaining work and actual progress without another parallel ledger.
Requested main-work configuration is `gpt-6-luna-medium`; the older Luna 5.6
probe is not proof of this configuration. No new model run or rollout is
authorized merely by recording this feedback.

### BAS-FB-046 — authorize recovery and sandbox repair

> Do whatever you need to do. If you can't get the credential stuff working, disable it. It shouldn't be active until Agent manager is reliable in the first place, so not sure why its on in the first place

> Fully and properly fix any and all sandbox issues

Status: recovery and scoped sandbox repair applied and verified. Local-owner
exchange and recovery-first adoption preserved the retained interactive run;
authentication remains enabled. The owner applied the scoped AppArmor profile,
and real native/workspace sandbox containment checks now pass with global
restrictions unchanged. Source fixes were adopted by both services. Full sandbox
API tests pass. A disposable Luna-medium worker now completes a source-only edit,
passes behavior/device checks and is denied control writes and host HTTP. Broader
unit failures, remaining authority/transport checks and the actual BAS delivery
pilot remain open. Keep BAS disabled until that pilot passes;
the existing integration checkpoint owns evidence and remaining limitations.

### BAS-FB-045 — consolidate existing teams and supervision

> It seems we are building multiple systems here that need to converge. There's the goal skill and related docs that need updating to use epochs properly (possibly), and the while supervision thing. We have a setup with prompt-manager delivery teams where a team can orchestrate and another supervises. We never got that fully working, but that seems like what would need updating to get this all working properly. Do you agree? Like instead of building a new orchestration and supervision setup, we streamline and fix what we alreay have, and make sure the bas stuff becomes a team? And maybe we allow teams to store data in scenarios as well so we don't have to move stuff?

> To be clear, the ideal solution must be CLEANER and more MAINTAINABLE than everything we have now. We have tried getting this working in the past and have failed. I don't just mean the current goal, but the whole supervision thing. So you need to make sure we're actually fixing and maturing instead of tacking on new things and making it messier. And we need to make sure the actual orchestration is done with CHEAP luna medium agents, and supervision is INFREQUENT with sol agents. Note that the models recently changed, so what agent-manager has for the models is likely incorrect. I believe they are all gpt 6 tag variants now.

> But yeah, I think if you properly document everything we're trying to achieve and work towards it properly and professionally and intelligently, we can simultaneously get the proper setup for the bas work as well as fix our setup for all of this long-running tyoe of work in the future

Status: open. Source: goal attachment `5fc98adc-1797-42b2-8614-562a14ff88c4`
in web-console session `3df7e216-b0b0-4a41-922d-1a5ef784f4b1`.
The existing [supervision contract](../../../../docs/agent-system/EFFORT_SUPERVISION.md#delivery-campaign-amendment--2026-09-26)
and [integration checkpoint](../../../../docs/agent-system/effort-supervision-validation.md#current-integration-checkpoint--2026-09-27)
own cross-scenario implementation. The old worker remains stopped. PM already
supports repo-root references to scenario-local documents; runtime protection,
independent acceptance, retention and useful pilot delivery remain unverified.

### BAS-FB-020/021/022/023/024/025/026/027/028/029/030/031/032/033/037/038 — pace and validation cadence

The repeated directive is to produce meaningful product progress faster, prefer
focused tests, stop repeatedly running broad Test Genie/evidence cycles and make
qualification serve delivery rather than replace it.

Status: open. The candidate-epoch protocol in TESTING.md now batches related
implementation and permits qualification only at an epoch boundary. The next
worker must report per-epoch product outcome and counts of rebuilds, restarts,
exact evidence phases and setpoint reads. Score movement alone does not resolve
this directive.

### BAS-FB-035 — possible cross-scenario safe-area drift

The operator reported growing bottom padding in the installed Git Control Tower
PWA and suspected BAS activity might be involved.

Status: externally filed and not attributed to BAS. Prior investigation found no
BAS writer or source change in GCT/RCL and identified a possible shared
safe-area policy mismatch, but device geometry remained unverified. Existing
report `knw-1790343012828318802` owns follow-up; do not file duplicates or alter
GCT under this goal without new evidence and authority.

### BAS-FB-036 — test-code quality

The operator asked for more professional test infrastructure with less
duplication, drift and code volume.

Status: open. Several helpers were consolidated, but the directive is not
resolved. Treat test debt as part of a product ownership-boundary epoch; do not
create a score-neutral helper-extraction epoch or add abstractions without a
measured reduction.

### BAS-FB-039 — epochs must span compactions

> This looks good, but I feel like it cluld still be inefficient if it picks too small of epochs. There really isn't too much room for it to do with sometime between compactions, so I'm worried that it might pick small sets of work and run into a similar issue as currently

Status: implemented in TESTING.md. An epoch is a meaningful independently
shippable vertical slice containing many work units and normally spanning
multiple compactions. Compaction is only an in-epoch checkpoint.

### BAS-FB-040 — active goal documentation is too large

> Sounds good. I think another issue we've been running into is the goal docs/notes getting too long and never being cleaned up. Is that something we should assess as well while we're about to change things? What can we do for that?

Status: implemented as a bounded active resume packet. Superseded progress and
feedback are compressed behind checksummed references; active state is updated
in place and has a 96 KiB orientation budget.

### BAS-FB-041 — apply the durable protocol now

> The agent has been stopped. Please perform all updates now and then give me the full updated goal message

Status: implemented by this documentation-control pass. It preserves the
stopped agent's product changes, forbids agent commits and makes the revised
goal point to the durable protocol rather than restating it.

### BAS-FB-042 — bound evidence growth

> Also if you could do something about cleaning up the evidence data and making sure that stays under control, that'd be great. There's like a million  lines of evidence data or something

Status: implemented as a bounded working-set policy plus recoverable archive.
At receipt, runtime evidence had about 977,000 text lines across 610 files
(38 MiB); durable documentation evidence had about 69,000 lines across 177
files (3.9 MiB). The current checkpoint records the post-cleanup counts and
archive verification.

### BAS-FB-043 — historical protocol directive

The verbatim feedback and accepted disposition are preserved in
[`operator-feedback-history-2026-09-27.md`](evidence/rehabilitation/operator-feedback-history-2026-09-27.md),
SHA-256 `14f7dd99b4fb93dd6bde9ab7d64844fd3fe25922ee007ec06f020ed70a2731f3`.

### BAS-FB-044 — historical campaign-control directive

> I stopped the agent. Do what you gotta do, and give me an updated goal message to resume it. Here is the current goal as a reminder:

The implemented disposition is preserved in
[`operator-feedback-history-2026-09-27.md`](evidence/rehabilitation/operator-feedback-history-2026-09-27.md).
