# Browser rehabilitation progress

This is the bounded resume view, not an execution transcript. Read
[TESTING.md](TESTING.md) and its linked contract before acting. Historical
chronology and raw owner payloads stay in the cited archives; do not append
tool transcripts here.

## Current standing — 2026-09-28 UTC

- Delivery team `browser-automation-studio-delivery` is disabled and serialized;
  no accepted candidate or qualification lease exists. The representative
  execution `de06300a-6060-4e31-9afe-55e3fee03a81` ended
  `budget_exhausted/wall_time`; it is not product acceptance. Do not enable or
  recreate the team.
- Prompt Manager's delivery team and Agent Manager's existing workflow remain
  the integration owners. Do not add a scheduler, worker-authored controller,
  Plan Manager plan, or duplicate ledger. The obsolete Swarm goal
  `browser-automation-studio-improve` was archived through its owner API.
- Source workflow validation/reconciliation passes at
  `sha256:b6fcbef7e31ed0284998a9a838e9518cc42712018a08ccb0e692afa67e57f60f`.
  The pinned graph is worker → independent review → owner qualification → end;
  worker limits are 24 tool calls, 16 turns, 900 seconds and 400,000 aggregate
  tokens. This is admission evidence, not a live pilot.
- Delivery uses owner-validated Codex `gpt-6-luna`/medium; independent review
  uses `gpt-6-sol`/medium. `/usr/bin/codex` is 0.156.1 and lists both models.
  A fresh `resource-codex models list --json` probe on 2026-09-28 was
  authoritative and contained both models; `resource-codex policy validate
  --against-live --json` returned `valid: true`. Shared discovery resolves the
  Vrooli shim to that launch binary; a partial cache/shim listing cannot imply
  GPT-6 absence.
- Generated-artifact freshness is owned by package/lifecycle owners. `protogen
  verify` and the lifecycle verifier run before consumers; generated-output
  declarations without a generation/build owner fail closed. Repository
  preflight covers both dedicated generators and build-owned projections;
  canonical Proto selection is keyed by declared `artifact_selection`, not a
  package name. This generalizes the stale-protobuf repair beyond Test Genie.
- Worker/review grants include the current navigation-events and recording-close
  owners but exclude campaign controls, evidence roots, lifecycle/restart and
  qualification effects. The previous pilot completed Luna work and a Sol
  rejection, then exhausted its wall-time after deterministic qualification
  preparation rejection; no accepted pilot exists.
- Control-plane restart ordering now stops before manifest/engagement reads, and
  shared CLI freshness manifests remove the old 414-MiB pre-stop hash path.
  Focused lifecycle/CLI tests pass; managed restart repeatability remains open.
- Sidecar manual restart no longer races the crash monitor: the supervisor now
  fences the exact intentionally closed process channel, so it cannot consume
  crash budget or launch a duplicate automatic restart. The regression passes
  repeatedly under `go test -race`; managed restart qualification is still
  intentionally open.
- Manual restart from `unrecoverable` now re-arms the monitor after health is
  restored. A follow-on crash is observed and recovered in the same regression;
  this closes a source-level supervision gap while leaving managed restart
  repeatability qualification open.
- Monitor ownership is generation-fenced so a retiring monitor cannot clear the
  state of a newly re-armed monitor during manual recovery. Repeated race tests
  pass; this is still source evidence rather than managed qualification.
- Managed close-after-driver-loss is repaired and has current receipts proving
  binding cleanup, `profile_persisted=false` for an absent session, and zero
  residual driver sessions. Broader E01 acceptance remains open.
- The managed BAS process is healthy on build
  `sha256:a67b3dc43ff22b99205cf0afbb1a7c3e8671c2e02cec3e701c9c3a73a76622`,
  but the current navigation source is newer than that build. Existing managed
  receipts bound to this identity are therefore stale for the current source;
  defer one coordinated refresh until E01's semantic exit gate rather than
  rebuilding after each implementation unit.

## Active candidate epoch E01 — navigation observation and managed shutdown

Candidate state: **implementation**

Qualification cycle: **unused**

This is one ownership boundary spanning status-wait cancellation,
authoritative navigation transitions, managed restart cleanup, and
driver/browser teardown. BAS-RF-148, BAS-RF-149 and BAS-RF-017, plus measured
net simplification, must pass before an independent review may freeze it. The
worker cannot choose/close the boundary, edit this file or issue qualification.

## Salvage review — not accepted

The read-only reviews remain at
[salvage-review-2026-09-27.md](evidence/rehabilitation/salvage-review-2026-09-27.md)
and [salvage-reassessment-2026-09-28.md](evidence/rehabilitation/salvage-reassessment-2026-09-28.md).
Source repairs are focused-test green, but managed status-wait proof,
recovered/export privacy, and an accepted owner-controlled candidate are
missing.

The navigation extraction is not yet proven simplification. Current files are
`useAINavigation.ts` 489 lines, `navigationEvents.ts` 365 lines, and
`useAINavigationEvents.ts` 149 lines: 1,003 lines total versus the 631-line
baseline. The lifecycle owner is below the 500-line cohesion threshold and
boundaries are explicit, but the extracted parser/event owners add 346 lines.
Shared navigation-envelope validation, observation fencing, and handoff
admission now each have one owner; focused tests prove behavior, but the
  overall surface remains net positive. Moving code is not debt reduction;
  further parser/lifecycle simplification or a stronger structural metric is
  required before freezing. The primary lifecycle owner itself is 489 lines,
down from the 631-line baseline, and known navigation messages now take one
type dispatch instead of up to four sequential parser attempts; retain these
as supporting metrics, not as proof that the whole surface is smaller.

## Verified current evidence

- API-core cleanup receives a fresh bounded context after HTTP drain and
  force-closes standard-server connections on timeout. UI transport loss is
  `observation_unavailable`; navigation identity and stop admission remain
  available, with successor admission fenced until settlement. Focused API,
  navigation, conversation and sidebar tests pass. On the refreshed managed
  build, the focused navigation-status owner tests for terminal snapshots,
  early wake, human handoff, timeout and context cancellation also pass;
  managed start → lost observation → recovered status → successor request
  remains unqualified.
- The current focused UI record-mode run passed 61/61, including the
  `REQ:BAS-RH-J24` recovery requirement (32 cases). This is source evidence,
  not managed qualification.
- Status observation now treats both structured failure responses and thrown
  transport errors as the same non-authoritative
  `observation_unavailable` transition. The navigation identity remains
  stoppable/recoverable; the new regression covers the thrown-error path.
- Conversation ownership now has a maintained cross-layer regression for the
  same path: observation loss keeps exactly one assistant message recoverable
  and abortable, and a later terminal event settles that message without a
  duplicate or orphan. The focused conversation suite is 28/28 green.
- The sidecar supervisor's manual-restart regression now passes under the race
  detector: an armed monitor observes the intentional process close without a
  second `Start` or restart-budget increment. This is source-level lifecycle
  evidence only; it does not replace managed restart qualification.
- The same supervisor test proves manual recovery from `unrecoverable` starts a
  fresh monitor and successfully handles the next crash. No duplicate monitor
  is created for ordinary restarts; managed process qualification remains
  deferred to the semantic exit gate.
- Supervisor monitor generations are fenced during that re-arm, preventing a
  retiring monitor's deferred cleanup from clearing the new monitor's state;
  the full package race suite passes repeatedly.
- The complete API sidecar package suite (`go test ./sidecar/...`) is green;
  this validates the supervisor change against its sidecar integration owners.
- Handoff command bookkeeping now has one `beginHandoff` owner and one
  `clearHandoffIfCurrent` owner shared by abort and resume. This removes the
  duplicated generation/in-flight mutation and keeps stale-command fencing
  identical across both commands; it is a local maintainability improvement,
  not yet proof that the whole navigation surface is smaller.
- Wire-specific navigation parsers are now private implementation details; the
  single typed dispatcher is the only parser boundary. This removes four
  unused exports without changing the focused record-mode behavior (60/60,
  including J24).
- The two synthetic source probes flagged for possible retirement are both
  green (reuse 17/17; session/frame 16/16). They remain temporarily because
  their 33 assertions are not yet proven to have one-to-one maintained-test
  coverage; deleting them now would trade visible complexity for lost
  diagnostics rather than simplification.
- The contract preparation validator and isolated input regression runner both
  pass after the navigation ownership changes; these checks confirm traceability
  and retained input semantics only, not managed/browser qualification.
- The existing `browser-automation-studio.qualify-candidate` composition has
  14 passing owner tests covering refusal-before-effects, exact WSS promotion,
  source-identity binding, stale/failed producer receipts, bounded typed
  evidence forwarding, uncertain effects, retained-cohort reuse and selected
  row failure. This validates the controller seam only; no live candidate lease
  or qualification run exists.
- Revalidation of the reused owner chain passes: Agent Manager workflow-runtime
  and orchestration tests, plus Prompt Manager's team-contract tests, are green
  from their owning Go modules. This is substrate evidence only; it does not
  admit the disabled BAS team or qualify E01.
- Passive-fidelity owner refresh passed on healthy build
  `sha256:0c62b8cf731ca1a68e82561d7b72114bc2eb67df4f7b3cefa81ab97899c46d46`:
  10,000 managed journal effects with unique ordered IDs, 10,000 applied-input
  receipts, zero primary-pool requests in 46.4 seconds; process-death/same-ID
  retry 1/1; selected browser semantics 3/3. Assembled receipts:
  `passive-fidelity-managed-current-20260928-r1-assembled.json`,
  `passive-fidelity-process-crash-current-20260928-r1-assembled.json`, and
  `passive-fidelity-semantics-current-20260928-r1-assembled.json`.
- Read-only setpoint program `prog_921d31dd-4139-4617-8989-dce7ff941064`
  completed with lifecycle freshness true but all 17 rows explicitly
  unavailable because the exact provider phase has not been admitted. Owner
  receipts are not promoted by inference; no qualification lease or provider
  phase was started.
- Managed J07 diagnostics on build `sha256:0c62b8cf…` include one passing line
  (input stop 163.1 ms, preparation 150 ms, cleanup 10.6 ms, recovery 8.84 s)
  and one same-build failure (input stop 1,697 ms, preparation 1,676 ms,
  cleanup 18 ms, recovery 9.45 s). Preserve both; do not widen the 1,000-ms
  band or assemble J07 from them.
- The current shared generated-artifact boundary passes `protogen verify` and
  focused Test Genie/validation-broker builds. The root preflight now
  materializes an immutable Proto artifact and CLI freshness stamp, avoiding
  per-invocation hashing without allowing stale generated output.
- `proto-health validate scenario test-genie --json` also passes with generation
  sync at L3; its health/layout/adoption warnings are advisory contract debt,
  not stale-generated-code failures.
- Navigation wire decoding now shares scalar/enum readers and one string-field
  projection loop; focused record-mode remains 60/60, TypeScript and scoped
  ESLint pass. This removes repeated type-check boilerplate, but measured
  ownership is still 489 + 365 + 149 = 1,003 lines and complexity is
  97 + 97 + 26 = 220, versus the 631-line monolith baseline; no net
  simplification claim is made until the remaining parser/lifecycle review
  either reduces that surface or records why the added recovery behavior earns
  it.
- Current owner-side privacy and shutdown checks remain green: vision redaction,
  navigation handler, vision service, supervisor race tests, and api-core server
  shutdown tests all pass. The server-owned long-poll has an independent
  cleanup budget and forced connection close on drain expiry; no stale-review
  inference is promoted as managed qualification.
- The event parser now uses one declared-type registry rather than a sequential
  switch, reducing parser complexity from 99 to 97 without changing its public
  boundary. Conversation debug `console.log` probes were removed; the focused
  UI surface remains 89/89 green, including the redaction component tests.
- Salvage findings for shared shutdown, observation-loss identity and UI action
  redaction are repaired and source-tested. Their old receipts are stale after
  navigation edits; current-build recovered/export privacy, credential-use
  preservation, probe ownership and real net simplification remain open.
- The campaign guard currently reports one implementation epoch; the active
  packet and 52-file runtime working set remain below their 96 KiB packet and
  128-file/16 MiB/250,000-line limits (current working set: 5,662,777 bytes,
  136,508 text lines).
  Current evidence is bounded; superseded cohorts must be archived as one
  dated tarball with manifest before any broad producer run.

## Next bounded actions

1. Keep E01 implementation open. Qualify the managed observation-loss →
   recovery → new-request agreement now that UI state, command admission and
   conversation history have maintained focused coverage.
2. Perform a genuine navigation parser/lifecycle simplification review. The
   shared admission seams are consolidated and event dispatch now selects one
   parser per message, but the 1,003-line ownership
   surface remains open. Remove additional duplicated transitions/branches or
   justify the extra parser surface with a measurable structural improvement;
   preserve focused recovery/admission tests. Do not count file moves or line
   movement alone.
3. Obtain current-build recovered-status and managed passive/export/
   legacy-at-rest privacy evidence. Do not rebuild or run broad suites unless a
   selected owner is invalidated.
4. Only after independent review accepts frozen content may the existing
   controller issue its one-use worker → Sol review → qualification lease. Do
   not enable the disabled BAS team before that gate.

## History and retrieval

The superseded full view is retained at
`evidence/rehabilitation/refactor-progress-active-2026-09-28-r3.md.gz`; its
manifest records SHA-256 and retrieval. Earlier chronology is in
`refactor-progress-precompact-2026-09-28.md.gz`,
`refactor-progress-stopped-2026-09-27.md.gz`, and the named salvage files.
Never delete a referenced artifact or use an archive as resume input.

At every checkpoint record only changed, verified, remaining and unverified
work. This mandate remains active until the operator stops or redirects it.
