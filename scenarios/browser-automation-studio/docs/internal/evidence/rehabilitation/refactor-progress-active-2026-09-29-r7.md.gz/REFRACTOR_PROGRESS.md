# Browser rehabilitation progress

This is the bounded resume projection, not a transcript. Read
[TESTING.md](TESTING.md) and its linked contract before acting. The superseded
projection is preserved at
`evidence/rehabilitation/refactor-progress-active-2026-09-29-r6.md.gz` with
manifest `evidence/rehabilitation/refactor-progress-active-2026-09-29-r6.manifest.json`.
Archives are retrieval records, never routine resume input.

## Current standing — 2026-09-29 UTC

- `browser-automation-studio-delivery` and `effort-supervision` are disabled;
  no worker, review or qualification lease is active. Enrollment is observation
  only. Do not enable or recreate a team.
- Use the existing Prompt Manager delivery team, Agent Manager owner workflow,
  Workspace Sandbox, and Test Genie/Program Runtime. Do not add a scheduler,
  worker-authored controller, Plan Manager plan, duplicate ledger or unrestricted
  campaign control. Scenario-owned docs remain canonical; the team stores only
  repo-root pointers and runtime owner identities.
- Delivery is `gpt-6-luna`/medium; independent review is infrequent
  `gpt-6-sol`/medium. A stale 5.6 catalog is not evidence that GPT-6 is absent.
  The standing grant is authorization-only: no target, admission receipt or
  settlement proof exists, so it must not be spent.
- The last fresh managed BAS build is
  `sha256:9125db30fde119a5fe6b169a9ad295873be5e77183e9489b630a6504015029b8`.
  The current setpoint is stale (`readable=0`, `unavailable=17`,
  `qualification_bound=false`) because source changed after that build. Do not
  rebuild or qualify until E01's semantic and simplification gates pass.
- Live non-archive rehabilitation evidence is 0 files/0 bytes/0 lines;
  superseded cohorts are compressed under the evidence archive. Never convert a
  stale build, timeout or historical receipt into qualification evidence.

## Active candidate epoch E01 — navigation observation and managed shutdown

Candidate state: **implementation**. Qualification cycle: **unused**.

This one ownership boundary covers status-wait cancellation, authoritative
navigation transitions, managed restart cleanup, driver/browser teardown,
BAS-RF-148, BAS-RF-149, BAS-RF-017 and measured simplification. A worker cannot
choose or close the boundary, edit this projection or acceptance records,
restart/rebuild BAS, run evidence producers, qualify, issue the setpoint, commit,
or broaden permissions. A compaction, test, defect or session end is a
checkpoint, not a new epoch.

## Verified current-source evidence

- Fresh local recheck on 2026-09-29: the UI project suites passed (boundaries
  1/1, stores 174/174, features-core 50/50, workflow-palette 6/6 and
  workflow-builder 13/13); focused navigation passed 35/35; API-core drain
  timeout/forced-close tests passed; BAS race-protected cancellation/recovery
  and receipt-validator owners passed; the two selected J07 driver tests and
  two session-idempotency tests passed; and `protogen verify` passed. These are
  source-owner checks only and do not refresh a managed build or qualify a
  receipt.
- The two historical standalone diagnostic probes are now absent from the
  working tree and have no active command references; their maintained driver
  coverage remains under `tests/unit/routes`, `tests/unit/session` and the
  record-mode integration owners. Historical manifests still reference the
  deleted probes as retrieval records only; no new probe path is retained.
- Governed setpoint read `prog_270e48fc-ea3e-4ade-b9b7-0128040c90f1` (2026-09-29)
  returned
  `status=partial`, `readable=0`, `unavailable=17`,
  `qualification_bound=false`, and `product_qualified=false`; it failed closed
  on stale managed artifacts because the running API predates the current
  `playwright_navigator.go` source. This is the expected unverified freshness
  result, not a product regression or permission to rebuild from the worker.
- Focused privacy-owner rechecks pass: durable recording redaction plus legacy
  read redaction, legacy proto timeline/replay export redaction, live/recovered
  Playwright and Claude navigation redaction, and AI element-analysis masking.
  These close no managed-build claim; recovered/export/legacy-at-rest runtime
  receipts remain explicitly unverified until a fresh candidate is admitted.
- The shared navigation redaction owner now also scans generic string-valued
  action details (including `result`/`text`) for assignment-shaped secrets when
  the selector is not itself sensitive. Ordinary browser text remains intact;
  the focused race-tested vision redaction cohort passes, including a generic
  `password=`/`token=` regression. This is source evidence only and does not
  refresh the stale managed candidate.
- The recording-domain project passes 645/645, including focused navigation,
  conversation, Recording API and vision-navigation checks (`REQ:BAS-RH-J24`
  45/45); TypeScript and scoped ESLint pass. These are source checks, not
  managed qualification.
- A fresh record-mode navigation run passes 35/35 after live WebSocket steps
  now restore `navigating` when the status observer was temporarily
  unavailable; the regression preserves the navigation identity and clears
  only the stale observation error. This is source evidence, not qualification.
- `useAINavigationRuntime.ts` now owns identity refs, cancellation controllers,
  reset/unmount lifecycle and one shared command/event ref contract. The public
  `useAINavigation.ts` is composition-only; `useAINavigationCommands.ts` owns
  start/abort/resume admission and handoff failure cleanup; WebSocket and
  recovery remain separate transport projections sharing the same fence.
  Public-hook-plus-command source is 456 lines versus the original 631; the
  complete navigation surface is now 1,159 versus 1,160 before this
  extraction. Command handoff generation and failure cleanup sit beside the
  request they fence, and the generation predicate/updater now live in the
  shared runtime-ref contract instead of being threaded through each hook.
  Command/runtime functions still measure 115/84 lines against the local
  60-line cohesion threshold. A targeted ESLint scan reports no
  cyclomatic-complexity warning; mechanically splitting the two cohesive hooks
  would duplicate their shared fence contract and increase the 1,159-line
  surface. Retain this as an evidence-backed irreducibility note
  until a lower-surface design exists; this is a verified ownership improvement,
  not E01 acceptance.
- `observation_unavailable` is non-authoritative: identity is retained for stop
  or recovery, and terminal/duplicate callbacks are fenced. Conversation uses
  one ordered message-patch effect (341→333 lines). Action display has one
  presentation redaction boundary; API callback normalization reuses one
  sanitized projection for history, recording and WebSocket paths.
- Navigation parsing has one dispatcher/shared readers; action-field complexity
  fell 15→5. The unused legacy AI-navigation schema family and UI interfaces
  were removed after repository-wide consumer searches. Orphan cleanup fell
  879→871 lines and gocyclo 224→219. These are local reductions, not readiness.
- A shared live/recovered-step factory was measured and rejected: formatting
  the helper raised the ownership surface from 1,186 to 1,194 lines without
  reducing behavior or complexity. The explicit projections remain until a
  genuinely lower-surface design is demonstrated.
- Removed a redundant `navigationCommandGenerationRef` redeclaration from the
  command-ref contract; the field is already supplied by the shared runtime
  contract. This is a one-line structural reduction with no behavior change.
  The handoff cleanup simplification reduced the active surface by nine more
  lines. Consolidating the generation fence and state updater into the shared
  runtime-ref contract then removed twelve lines of duplicate option/interface
  plumbing and reduced the command-hook warning from 117 to 115 lines.
- Hardened event-parser dispatch against inherited object keys such as
  `__proto__`; malformed event names now return `null` instead of attempting
  to call a prototype value. The regression is covered by the focused
  navigation suite. This adds one guarded lookup line and is a reliability
  improvement. Removing the temporary status-observer refs adapter then
  reduced the public hook by six lines, leaving the complete measured surface
  one line below the 1,160 baseline. The parser reliability guard is not
  hidden as a debt reduction.
- After that plumbing simplification, the full record-mode project remained
  green at 31 files / 645 tests, while the focused navigation requirement
  remained 35/35. This is source evidence only; the managed candidate is still
  stale and no qualification lease is active.
- Bound rehabilitation setpoint reads now fail closed before Test Genie
  receipt/run/findings reads when a returned capture record lacks the current
  managed-build identity or required workload contract. An absent capture
  remains an independent unavailable row so other bound owner capabilities can
  still be evaluated. Program-runtime qualification/workflow tests pass 73/73
  with 63 subtests; this prevents stale capture evidence from being borrowed
  and avoids unnecessary owner reads.
- API-core shutdown keeps owner cleanup running after the short HTTP drain; the
  driver manager suite passes 75/75, API-core/BAS vision suites pass with race
  detection, and generated-artifact verification passes. Recovery/export privacy,
  desktop/mobile/native preservation and managed restart behavior remain
  unverified.
- The scheduler shutdown owner now cancels its parent context before draining
  cron, scheduled workflows inherit that context, and BAS cleanup calls its
  bounded `StopContext`. Focused scheduler race coverage and the full API Go
  suite pass; this closes the source-level path where a scheduled workflow
  could hold managed cleanup past its budget. A real managed restart remains
  required before RF-148/RF-149 acceptance.
- The protected rehabilitation workflow now exposes only the E01 lifecycle,
  navigation and privacy source/test ownership surface to the worker and
  reviewer snapshot; campaign docs, qualification programs, evidence roots and
  unrelated recording routes remain outside the boundary. Owner validation and
  reconciliation activated revision `1.1.0`, digest
  `sha256:9009102ac0eeb0fe99b2392ef66685e56da1848c338baa852966d75df57cf522`.
  This repairs the controller boundary without widening campaign or evidence
  permissions; it does not start a worker or qualify the candidate.
- Strong salvage review of the accumulated worktree still rejects freezing the
  candidate: the navigation ownership surface is 1,159 lines (456 public
  hook/command, 122 runtime, 176 event owner, 377 parser, 28 shared refs)
  versus 1,160 before extraction, while the richer recovery/privacy behavior
  and its dependency burden are not yet shown to be net simpler. Retain the
  behavioral repairs and focused regressions, but do not treat file movement,
  green tests, scheduler repair or workflow reconciliation as acceptance. The
  next review must either demonstrate a lower-surface design with preserved
  fences or retain this measured irreducibility disposition and proceed to the
  owner-controlled managed gate.
- The fresh UI type-check then exposed and fixed one extraction defect: the
  status-observation projection referenced a nonexistent
  `NavigationStatusObserverRefs` type after the runtime split. It now uses the
  shared `AINavigationRuntimeRefs` contract, and `pnpm type-check` passes with
  exit 0. This is a correctness repair, not a simplification or qualification
  result; the managed candidate remains stale.
- A read-only Agent Manager workflow simulation now resolves the reconciled
  definition to exactly `worker → review → qualify`, with both terminal paths
  (`end` and `end-rejected`) and the expected Luna delivery / Sol review
  profiles. The simulation did not dispatch a run; it verifies the controller
  graph and current digest only.
- The authoritative workflow read confirms the worker write grant and review
  snapshot contain the same 44 paths, with no missing or extra review source.
  This keeps the reviewer from judging a different candidate surface while
  preserving the exclusion of campaign controls and evidence producers.
- The first bounded Tidiness Manager run found a stale API registry row; managed
  `make restart` restored it. A second run found a numeric Go-duration/string
  response mismatch; the CLI now accepts both forms with regression tests.
  `GOWORK=off go test ./...` in its CLI passes, and a bounded smart scan analyzed
  one current navigation file with zero findings. CLI lint is unverified because
  the installed Go 1.25 toolchain cannot type-check a vendored package requiring
  Go 1.26; scenario-wide tidiness remains unmeasured.
- Runtime inventory including untracked source is 283,112 lines versus 284,443
  baseline (-1,331), while API runtime Go gocyclo is 16,539 versus 16,405
  (+134). Size alone is not acceptance; shared infrastructure additions and
  their operational burden remain in the accounting boundary.

## Required next work

1. Preserve the current parser/lifecycle ownership unless a proposed redesign
   lowers both the measured surface and its dependency burden. The 115/84-line
   command/runtime cohesion warning now has an evidence-backed irreducibility
   disposition; do not mechanically split it, count wrappers, or repeat test
   churn. Any new design must show a real before/after reduction.
2. Refresh this projection only with changed, verified, remaining and unverified
   facts. Keep live evidence under campaign limits; archive superseded cohorts
   with a manifest before any broad producer run.
3. After semantic exit and measured simplification, freeze the candidate and get
   independent Sol review. Only an accepted review may admit the one-use
   worker→review→qualification operation through existing owners.
4. Do not spend the standing grant until a concrete non-BAS target and current
   GPT-6 admission/settlement receipt exist. Unknown usage is not zero.
5. Resolve owner-backed review for the changed no-lifecycle row and failed
   finalization heartbeat row; preserve proven-empty rows. Then refresh only
   invalidated cohorts on a fresh owner-controlled build and run one exact
   qualification/setpoint cycle followed by adversarial review.

## Evidence and history

Superseded working sets remain in
`../.vrooli/runtime/rehabilitation-evidence/archive/`; earlier progress
projections are retained in the named r5/r4/r3 archives. This mandate remains
active until the operator stops or redirects it.
